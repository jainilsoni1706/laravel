<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('username')->unique();
            $table->string('firstname');
            $table->string('lastname');
            $table->string('email')->unique();
            $table->bigInteger('phone')->unique();
            $table->integer('otp')->nullable();
            $table->string('profile')->default("profile.png");
            $table->string('backup_email')->nullable();
            $table->string('site_email')->unique()->nullable();
            $table->text('address')->nullable();
            $table->integer('country')->nullable();
            $table->integer('gender')->nullable()->comment("1 = Male, 2 = Female, 3 = Non-Binary");
            $table->text('bio')->nullable();
            $table->date('dob')->nullable();
            $table->integer('occupation')->nullable();
            $table->text('google_token')->unique()->nullable();
            $table->text('facebook_token')->unique()->nullable();
            $table->text('github_token')->unique()->nullable();
            $table->text('linkedin_token')->unique()->nullable();
            $table->text('instagram_token')->unique()->nullable();
            $table->text('twitter_token')->unique()->nullable();
            $table->text('email_token')->unique()->nullable();
            $table->datetime('disable_date')->nullable();
            $table->string('status')->default(1);
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
