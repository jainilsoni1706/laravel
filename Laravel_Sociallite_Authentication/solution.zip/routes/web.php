<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Authentication;
use App\Http\Controllers\Management;
use Illuminate\Support\Facades\DB;

//clear cache
Route::get('/cc', function() {
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('config:clear');
    session()->flash('success', 'Cache cleared successfully');
    return back();
});

//login view
Route::get('/',function()
{

    //activate those user who have not activated their account
    foreach(DB::table("users")->where("status",0)->where("disable_date","!=","")->get() as $x)
    {
        if(date("Y-m-d H:i:s") > $x->disable_date)
        {
            DB::table("users")->where("id",$x->id)->update(["status"=>1,"disable_date"=>NULL]);
        }
    }

    if(session()->has('X_Auth_User_ID_SolutionFinder1706') && session()->has("X_Auth_User_Email_SolutionFinder1706"))
    {
        return redirect('/home');
    } 
    else
    {
        return view('login');
    }
});

//register view
Route::get('/signup',function()
{

    //activate those user who have not activated their account
    foreach(DB::table("users")->where("status",0)->where("disable_date","!=","")->get() as $x)
    {
        if(date("Y-m-d H:i:s") > $x->disable_date)
        {
            DB::table("users")->where("id",$x->id)->update(["status"=>1,"disable_date"=>NULL]);
        }
    }

    if(session()->has('X_Auth_User_ID_SolutionFinder1706') && session()->has("X_Auth_User_Email_SolutionFinder1706"))
    {
        return redirect('/home');
    } 
    else
    {
        return view('signup');
    }
});

//login
Route::post('auth/login',[Authentication::class,'login']);

//register
Route::post('auth/register',[Authentication::class,'register']);

//google
Route::get('auth/google', [Authentication::class,'redirectToGoogle']);
Route::get('auth/google/callback', [Authentication::class,'handleGoogleCallback']);

//github
Route::get('auth/github', [Authentication::class,'redirectToGithub'])->name('auth.github');
Route::get('auth/github/callback', [Authentication::class,'handleGithubCallback']);

//facebook
Route::get('auth/facebook', [Authentication::class,'redirectToFacebook'])->name('auth.facebook');
Route::get('auth/facebook/callback', [Authentication::class,'handleFacebookCallback']);

//twitter
Route::get('auth/twitter', [Authentication::class,'redirectToTwitter'])->name('auth.twitter');
Route::get('auth/twitter/callback', [Authentication::class,'handleTwitterCallback']);

//instagram
Route::get('auth/instagram', [Authentication::class,'redirectToInstagram'])->name('auth.instagram');
Route::get('auth/instagram/callback', [Authentication::class,'handleInstagramCallback']);

//linked in
Route::get('auth/linkedin', [Authentication::class,'redirectToLinkedin'])->name('auth.linkedin');
Route::get('auth/linkedin/callback', [Authentication::class,'handleLinkedinCallback']);

Route::middleware(['Authentication'])->group(function () {

    //home view
    Route::get('/home',[Authentication::class,'homeView']);

    //profile view
    Route::get('/profile',[Authentication::class,'profileView']);

    //logout
    Route::get('/logout',[Authentication::class,'logout']);

    //disable account
    Route::get('/disableaccount',[Authentication::class,'disableAccount']);

    //edit profile
    Route::post('editprofile',[Authentication::class,'editProfile']);


        Route::middleware(['Setup'])->group(function () {

            Route::get('upload',[Management::class,'uploadSolution']);
            Route::post('/getTopic',[Management::class,'getTopic']);

            Route::post('/uploadsolutionx',[Management::class,'uploadSolutionX']);

            Route::get('/mysolution',[Management::class,'mySolutionView']);
        
            Route::get('/read/{solution_id}',[Management::class,'readSolution']);

            Route::post("/comment_on_solution",[Management::class,'commentOnSolution']);
        });

});