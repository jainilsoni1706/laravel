<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API;


//login
Route::post("login",[API::class,'login']);

//register
Route::post("signup",[API::class,'signup']);

//get all user record
Route::get("get_all_user",[API::class,'get_all_user']);

//delete user
Route::post("delete_user",[API::class,'deleteUser']);