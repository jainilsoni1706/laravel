@include("include.header")

<style>
    label
    {
        margin-top: 10px;
    }
</style>

     <!--section-heading-->
     <div class="section-heading " >
        <div class="container-fluid">
             <div class="section-heading-2">
                 <div class="row">
                     <div class="col-lg-12">
                         <div class="section-heading-2-title">
                             <h1>Profile</h1>
                         </div>
                     </div>  
                 </div>
             </div>
         </div>
    </div>

    <!--about-us-->
    <section class="about-us">
        <div class="container-fluid">
            <div class="about-us-area">
               <form action="{{ url('editprofile') }}" enctype="multipart/form-data" method="POST"> @csrf
                <div class="row ">

                    <div class="col-lg-6 ">
                        <label for="firstname"> Firstname </label>
                        <input type="text" class="form-control" name="firstname" id="firstname" value="{{ $user->firstname }}">                                
                    </div>

                    <div class="col-lg-6 ">
                        <label for="lastname"> Lastname </label>
                        <input type="text" class="form-control" name="lastname" id="lastname" value="{{ $user->lastname }}">                                
                    </div>

                    <div class="col-lg-12 ">
                        <label for=""> Username </label>
                        <input type="text" class="form-control" disabled value="{{ $user->username }}">                                
                    </div>

                    <div class="col-lg-12 ">
                        <label for=""> Email Address </label>
                        <input type="text" class="form-control" disabled value="{{ $user->email }}">                                
                    </div>

                    <div class="col-lg-12 ">
                        <label for=""> Phone Number </label>
                        <input type="text" class="form-control" disabled value="{{ $user->phone }}">                                
                    </div>

                    <div class="col-lg-12 ">
                        <label for="siteemail"> Site Email </label>
                        <input type="text" class="form-control" name="siteemail" id="siteemail" placeholder="E.g: jainilsoni1706" value="{{ $user->site_email }}">                                
                    </div>

                    <div class="col-lg-6 ">
                        <label for="occ"> Occupation </label>
                        <select name="occupation" id="occ" class="form-control">
                            @forelse (DB::table('category')->where('status',1)->get() as $category)
                                    <option value="{{$category->id}}" @if($category->id == $user->occupation) selected @endif> {{$category->name}} </option>                                
                            @empty
                                    <option disabled selected> --- No Occupation Listed Right Now --- </option>
                            @endforelse
                        </select>
                    </div>



                    <div class="col-lg-6 ">
                        <label for="country"> Country </label>
                        <select name="country" id="country" class="form-control">
                            @forelse(DB::table("countries")->get() as $country)
                                    <option value="{{$country->id}}" @if($country->id == $user->country) selected @endif > {{$country->name}} </option>
                            @empty
                                    <option value="5"> --- No country listed right now --- </option>
                            @endforelse
                        </select>
                    </div>

                    <div class="col-lg-6 ">
                        <label for="gender"> Gender </label>
                        <select name="gender" id="gender" class="form-control">
                            <option value="1" @if($user->gender == 1) selected @endif> Male </option>
                            <option value="2" @if($user->gender == 2) selected @endif> Female </option>
                            <option value="3" @if($user->gender == 3) selected @endif> Non-Binary </option>
                        </select>
                    </div>

                    <div class="col-lg-6 ">
                        <label for="dob"> D.O.B </label>
                        <input type="date" name="dob" id="dob" value="{{ $user->dob }}" class="form-control">
                    </div>

                    <div class="col-lg-12 ">
                        <label for="bio"> Bio </label>
                        <textarea name="bio" id="bio" class="form-control" placeholder="Write something about your self..."> {{$user->bio}} </textarea>
                    </div>

                    <div class="col-sm-12"><br></div>

                    <div class="col-lg-12">
                        <center>
                            <button type="submit" class="btn-custom"> Save </button>
                        </center>
                    </div>



                </div>
               </form>
            </div>
        </div>
    </section> 
   
    <center>
        <a href="{{ url('disableaccount') }}">
            <button class="btn-custom" style="background: #dd2d20;">Disable my Account for 30 days</button>
        </a>
    </center>
    <br><br>

        
   
    @include("include.message")
    @include("include.footer")
