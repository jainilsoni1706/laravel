<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" sizes="16x16" href="{{Solution::img('favicon.png')}}">
    <title> Solution </title>
    <link rel="stylesheet" href="{{Solution::css('bootstrap.min')}}">
    <link rel="stylesheet" href="{{Solution::css('owl.carousel')}}">
    <link rel="stylesheet" href="{{Solution::css('line-awesome.min')}}">
    <link rel="stylesheet" href="{{Solution::css('fontawesome')}}">

    <!-- main style -->
    <link rel="stylesheet" href="{{Solution::css('style')}}">
    <link rel="stylesheet" href="{{Solution::css('custom')}}">

    <style>
        .btn-cont
        {
            width: 100%;
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
        }
    </style>

</head>

<body>
    <!--loading -->
    <div class="loader">
        <div class="loader-element"></div>
      </div>

      <!--Login-->
    <section class="login">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-8 m-auto">
                    <div class="login-content">
                        <h4>Login</h4>
                        <p></p>
                        <form  action="{{ url('auth/login') }}" class="sign-form widget-form " method="POST"> @csrf
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Username,Email or Phone Number" name="email" value="">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" placeholder="Password" name="password" value="">
                            </div>
                            <div class="sign-controls form-group">
                                <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="rememberMe">
                                    <label class="custom-control-label" for="rememberMe">Remember Me</label>
                                </div>
                                <a href="#" class="btn-link ">Forgot Password?</a>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn-custom">Login in</button>
                            </div>
                            <div class="btn-cont x">
                                <button class="btn-custom"> <a href="{{ url('auth/google') }}">Google</a> </button>
                                <button class="btn-custom"> <a href="{{ url('auth/github') }}">Github</a> </button>
                            </div>

                            <div class="btn-cont">
                                <button class="btn-custom"> <a href="{{ url('auth/facebook') }}">Facebook</a> </button>    
                                <button class="btn-custom"> <a href="{{ url('auth/linkedin') }}">LinkedIn</a> </button>
                                {{-- <button class="btn-custom"> <a href="{{ url('auth/twitter') }}">Twitter</a> </button> --}}
                                {{-- <button class="btn-custom"> <a href="{{ url('auth/instagram') }}">Instagram</a> </button>     --}}
                            </div>
                            <p class="form-group text-center">Don't have an account? <a href="{{ url('signup') }}" class="btn-link">Create One</a> </p>
                        </form>
                    </div> 
                </div>
            </div>
        </div>
    </section>       


    <!--instagram-->
    <div class="instagram">
        <div class="container-fluid">
            <div class="instagram-area">
                <div class="instagram-list">
                    <div class="instagram-item">
                        <a href="#">
                            <img src="{{Solution::img('instagram/1.jpg')}}" alt="">
                            <div class="icon">
                            <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="{{Solution::img('instagram/2.jpg')}}" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="{{Solution::img('instagram/3.jpg')}}" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="{{Solution::img('instagram/4.jpg')}}" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="{{Solution::img('instagram/5.jpg')}}" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="{{Solution::img('instagram/6.jpg')}}" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>


   


    
    <script src="{{Solution::js("jquery.min")}}"></script>
    <script src="{{Solution::js("popper.min")}}"></script>
    <script src="{{Solution::js("bootstrap.min")}}"></script>
    
    <script  src="{{Solution::js("theia-sticky-sidebar")}}"></script>
    <script src="{{Solution::js("ajax-contact")}}"></script>
    <script src="{{Solution::js("owl.carousel.min")}}"></script>
    <script src="{{Solution::js("switch")}}"></script>
    <script src="{{Solution::js("jquery.marquee")}}"></script>

    <script src="{{Solution::js("main")}}"></script>

</body>
</html>
@include("include.message")