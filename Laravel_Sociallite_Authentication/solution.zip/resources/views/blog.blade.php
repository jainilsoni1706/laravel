@include("include.header")

   <!--Sections heading-->
   <div class="section-heading " >
    <div class="container-fluid">
         <div class="section-heading-1">
             <div class="row">
                 <div class="col-lg-10">
                     <div class="section-heading-1-title">
                         <h1>My Solutions</h1>
                     </div>
                 </div>  
             </div>
         </div>
     </div>
</div>
 
<!--blog-layout-1-->
 <div class="blog-layout-1">
     <div class="container-fluid">
         <div class="row">
             <div class="col-lg-12">


                @forelse ($data as $x)
                <div class="post-list post-list-style1 pt-0">
                    <div class="post-list-image">
                        <a href="post-single.html">
                            <img src="{{ URL::asset("public/uploads/thumbnail/$x->thumbnail") }}" alt="">
                        </a>
                    </div>
                    <div class="post-list-title">
                        <div class="entry-title">
                            <h4>
                                <a href='{{ url("/read/$x->solution_id") }}'> {{$x->title}} </a>
                            </h4>
                        </div>
                    </div>
                </div>    
                @empty
                    <h3> You have not uploaded any Solution </h3>
                @endforelse


             </div>
         </div>
     </div>
 </div>

      

@include("include.footer")
@include("include.message")