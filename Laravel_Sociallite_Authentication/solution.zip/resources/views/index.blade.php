@include("include.header")    
    <!-- blog-home8-->
    <section class="blog blog-home8" style="background-image: url('assets/img/blog/36.jpg')"> 
        <div class="container">
            <div class="row">
                <div class="col-lg-8 m-auto">         
                    <div class="blog-inner" >
                        <div class="blog-banner">
                            <div class="post-overly">
                                <div class="post-overly-content">
                                    <div class="entry-cat">
                                        <a href="blog-layout-1.html" class="category-style-2">Branding</a>
                                    </div>
                                    <h2 class="entry-title">
                                        <a href="post-single.html">Architecture is a visual art and the buildings speak for them selves </a>
                                    </h2>
                                    <ul class="entry-meta">
                                        <li class="post-author"> <a href="author.html">Meriam Smith</a></li>
                                        <li class="post-date"> <span class="line"></span> Fabuary 10 ,2022</li>
                                        <li class="post-timeread"> <span class="line"></span> 15 mins read</li>
                                    </ul>
                                </div>   
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </section>


    <!-- Blog Layout-8-->
    <section class="blog-layout-8">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-10 m-auto">
                    <div class="section-title text-center">
                        <h3>Popular Articles </h3>
                        <p>Discover the most outstanding articles in all topics .</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-10 m-auto"> 

                    <!--post 1-->
                    <div class="post-list post-list-style8">
                        <div class="post-list-image">
                            <a href="post-single.html">
                                <img src="assets/img/blog/25.jpg" alt="">
                            </a>
                        </div>
                        <div class="post-list-content">
                            <h3 class="entry-title">
                                <a href="post-single.html">Business has only two functions marketing and innovation.</a>
                            </h3>  
                            <ul class="entry-meta">
                                <li class="post-author-img"><img src="assets/img/author/1.jpg" alt=""></li>
                                <li class="post-author"> <a href="author.html">Meriam Smith</a></li>
                                <li class="entry-cat"> <a href="blog-layout-1.html" class="category-style-1 "> <span class="line"></span> interior</a></li>
                                <li class="post-date"> <span class="line"></span> february 10 ,2022</li>
                            </ul>
                            <div class="post-exerpt">
                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Autem similique temporibus blanditiis architecto tempora ducimus, 
                                    iusto vero facilis aperiam asperiores earum laboriosam repudiandae esse eaque possimus sit error, distinctio ea provident reiciendis.
                                    </p>
                            </div>
                            <div class="post-btn">
                                <a href="post-single.html" class="btn-read-more">Continue Reading <i class="las la-long-arrow-alt-right"></i></a>
                            </div>
                        </div>
                    </div>  

                    <!--post 2-->
                    <div class="post-list post-list-style8">
                        <div class="post-list-image">
                            <a href="post-single.html">
                                <img src="assets/img/blog/33.jpg" alt="">
                            </a>
                        </div>
                        <div class="post-list-content">
                            <h3 class="entry-title">
                                <a href="post-single.html">It’s easier to ask Forgiveness than it is to get Permission.</a>
                            </h3>  
                            <ul class="entry-meta">
                                <li class="post-author-img"><img src="assets/img/author/1.jpg" alt=""></li>
                                <li class="post-author"> <a href="author.html">Meriam Smith</a></li>
                                <li class="entry-cat"> <a href="blog-layout-1.html" class="category-style-1 "> <span class="line"></span> branding</a></li>
                                <li class="post-date"> <span class="line"></span> february 10 ,2022</li>
                            </ul>
                            <div class="post-exerpt">
                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Autem similique temporibus blanditiis architecto tempora ducimus, 
                                    iusto vero facilis aperiam asperiores earum laboriosam repudiandae esse eaque possimus sit error, distinctio ea provident reiciendis.
                                    </p>
                            </div>
                            <div class="post-btn">
                                <a href="post-single.html" class="btn-read-more">Continue Reading <i class="las la-long-arrow-alt-right"></i></a>
                            </div>
                        </div>
                    </div>

                    <!--post 3-->
                    <div class="post-list post-list-style8">
                        <div class="post-list-image">
                            <a href="post-single.html">
                                <img src="assets/img/blog/32.jpg" alt="">
                            </a>
                        </div>
                        <div class="post-list-content">
                            <h3 class="entry-title">
                                <a href="post-single.html">The best marketing doesn't feel like marketing</a>
                            </h3>  
                            <ul class="entry-meta">
                                <li class="post-author-img"><img src="assets/img/author/1.jpg" alt=""></li>
                                <li class="post-author"> <a href="author.html">Meriam Smith</a></li>
                                <li class="entry-cat"> <a href="blog-layout-1.html" class="category-style-1 "> <span class="line"></span> marketing</a></li>
                                <li class="post-date"> <span class="line"></span> february 10 ,2022</li>
                            </ul>
                            <div class="post-exerpt">
                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Autem similique temporibus blanditiis architecto tempora ducimus, 
                                    iusto vero facilis aperiam asperiores earum laboriosam repudiandae esse eaque possimus sit error, distinctio ea provident reiciendis.
                                    </p>
                            </div>
                            <div class="post-btn">
                                <a href="post-single.html" class="btn-read-more">Continue Reading <i class="las la-long-arrow-alt-right"></i></a>
                            </div>
                        </div>
                    </div>

                    <!--post 4-->
                    <div class="post-list post-list-style8">
                        <div class="post-list-image">
                            <a href="post-single.html">
                                <img src="assets/img/blog/38.jpg" alt="">
                            </a>
                        </div>
                        <div class="post-list-content">
                            <h3 class="entry-title">
                                <a href="post-single.html">Your genetics load the gun your lifestyle pulls the trigger..</a>
                            </h3>  
                            <ul class="entry-meta">
                                <li class="post-author-img"><img src="assets/img/author/1.jpg" alt=""></li>
                                <li class="post-author"> <a href="author.html">Meriam Smith</a></li>
                                <li class="entry-cat"> <a href="blog-layout-1.html" class="category-style-1 "> <span class="line"></span>design</a></li>
                                <li class="post-date"> <span class="line"></span> february 10 ,2022</li>
                            </ul>
                            <div class="post-exerpt">
                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Autem similique temporibus blanditiis architecto tempora ducimus, 
                                    iusto vero facilis aperiam asperiores earum laboriosam repudiandae esse eaque possimus sit error, distinctio ea provident reiciendis.
                                    </p>
                            </div>
                            <div class="post-btn">
                                <a href="post-single.html" class="btn-read-more">Continue Reading <i class="las la-long-arrow-alt-right"></i></a>
                            </div>
                        </div>
                    </div> 

                    <!--post 5-->
                    <div class="post-list post-list-style8">
                        <div class="post-list-image">
                            <a href="post-single.html">
                                <img src="assets/img/blog/18.jpg" alt="">
                            </a>
                        </div>
                        <div class="post-list-content">
                            <h3 class="entry-title">
                                <a href="post-single.html">Designers are meant to be loved, not to be understood.</a>
                            </h3>  
                            <ul class="entry-meta">
                                <li class="post-author-img"><img src="assets/img/author/1.jpg" alt=""></li>
                                <li class="post-author"> <a href="author.html">Meriam Smith</a></li>
                                <li class="entry-cat"> <a href="blog-layout-1.html" class="category-style-1 "> <span class="line"></span> livestyle</a></li>
                                <li class="post-date"> <span class="line"></span> february 10 ,2022</li>
                            </ul>
                            <div class="post-exerpt">
                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Autem similique temporibus blanditiis architecto tempora ducimus, 
                                    iusto vero facilis aperiam asperiores earum laboriosam repudiandae esse eaque possimus sit error, distinctio ea provident reiciendis.
                                    </p>
                            </div>
                            <div class="post-btn">
                                <a href="post-single.html" class="btn-read-more">Continue Reading <i class="las la-long-arrow-alt-right"></i></a>
                            </div>
                        </div>
                    </div> 

                    <!--post 6-->
                    <div class="post-list post-list-style8">
                        <div class="post-list-image">
                            <a href="post-single.html">
                                <img src="assets/img/blog/19.jpg" alt="">
                            </a>
                        </div>
                        <div class="post-list-content">
                            <h3 class="entry-title">
                                <a href="post-single.html">Design is as much an act of spacing as an act of marking.</a>
                            </h3>  
                            <ul class="entry-meta">
                                <li class="post-author-img"><img src="assets/img/author/1.jpg" alt=""></li>
                                <li class="post-author"> <a href="author.html">Meriam Smith</a></li>
                                <li class="entry-cat"> <a href="blog-layout-1.html" class="category-style-1 "> <span class="line"></span> design</a></li>
                                <li class="post-date"> <span class="line"></span> february 10 ,2022</li>
                            </ul>
                            <div class="post-exerpt">
                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Autem similique temporibus blanditiis architecto tempora ducimus, 
                                    iusto vero facilis aperiam asperiores earum laboriosam repudiandae esse eaque possimus sit error, distinctio ea provident reiciendis.
                                    </p>
                            </div>
                            <div class="post-btn">
                                <a href="post-single.html" class="btn-read-more">Continue Reading <i class="las la-long-arrow-alt-right"></i></a>
                            </div>
                        </div>
                    </div> 

                </div>
            </div>
        </div>
    </section>

    <!--pagination-->
    <div class="pagination">
        <div class="container-fluid">
            <div class="pagination-area ">
                <div class="row"> 
                    <div class="col-md-10 m-auto">
                        <div class="pagination-list">
                            <ul class="list-inline">
                                <li><a href="#" ><i class="las la-arrow-left"></i></a></li>
                                <li><a href="#" class="active">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li><a href="#">4</a></li>
                                <li><a href="#" ><i class="las la-arrow-right"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

     <!--instagram-->
     <div class="instagram">
        <div class="container-fluid">
            <div class="instagram-area">
                <div class="instagram-list">
                    <div class="instagram-item">
                        <a href="#">
                            <img src="assets/img/instagram/1.jpg" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>

                    <div class="instagram-item">
                        <a href="#">
                            <img src="assets/img/instagram/2.jpg" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="assets/img/instagram/3.jpg" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="assets/img/instagram/4.jpg" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="assets/img/instagram/5.jpg" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="assets/img/instagram/6.jpg" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include("include.message")
 @include("include.footer")