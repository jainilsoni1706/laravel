@include("include.header")
<script src="https://cdn.ckeditor.com/4.18.0/standard/ckeditor.js"></script>

<style>
    .col-sm-12 
    {
        margin-bottom: 10px;
    }

</style>

     <!--section-heading-->
     <div class="section-heading " >
        <div class="container-fluid">
             <div class="section-heading-2">
                 <div class="row">
                     <div class="col-lg-12">
                         <div class="section-heading-2-title">
                             <h1>Upload a Solution</h1>
                         </div>
                     </div>  
                 </div>
             </div>
         </div>
    </div>

    <!--about-us-->
    <section class="about-us">
        <div class="container-fluid">
            <div class="about-us-area">


                <form action="{{ url('/uploadsolutionx') }}" method="POST" enctype="multipart/form-data">@csrf
                    <div class="row">
                        <div class="col-sm-12">
                            <label for="category">Select Category</label>
                            <select class="form-control" id="category" name="category">
                                <option disabled selected> --- Select one of these topic --- </option>
                                @forelse (DB::table("category")->where('status',1)->get() as $category)
                                    <option value="{{ $category->id }}"> {{ $category->name }} </option>
                                @empty
                                    <option disabled selected> --- No Category Available --- </option>
                                @endforelse
                            </select>
                        </div>

                        <div class="col-sm-12">
                            <label for="topic">Select Category</label>
                            <select class="form-control" id="topic" name="topic">
                                    <option disabled selected> --- Select a Category --- </option>
                            </select>
                        </div>
    
                        <div class="col-sm-12">
                            <label for="title">Title</label>
                            <input type="text" name="title" id="title" class="form-control" placeholder="Enter Title">
                        </div>

                        <div class="col-sm-12">
                            <label for="thm">Thumbnail</label>
                            <input type="file" name="thumbnail" id="thm" class="form-control">
                        </div>

                        <div class="col-sm-12">
                            <label for="editor">Editor</label>
                            <textarea class="form-control" id="editor" name="editor"></textarea>
                        </div>
        
                        <div class="col-sm-12">
                            <label for="desc">Description</label>
                            <textarea name="description" id="desc" class="form-control"></textarea>
                        </div>

                        <div class="col-sm-6">
                            <label for="prime">Paid Content</label>
                            <select name="prime" id="prime" class="form-control">
                                <option value="0" selected> Free </option>
                                <option value="1"> Paid </option>
                            </select>
                        </div>

                        <div class="col-sm-6">
                            <label for="coin">Coin</label>
                            <input type="number" name="coin" id="coin" class="form-control"> 
                        </div>

                        <div class="col-sm-12" style="margin-top:30px;">
                                <button type="submit" class="btn-custom"> Post </button>
                        </div>

                    </div>
                </form>

            </div>
        </div>
    </section> 



@include("include.footer")

<script>
    //on change of category get data of topic from database ajax
    $("#category").change(function()
    {
        $("#topic").empty();

        var category_id = $(this).val();
        $.ajax({
            url: "{{ url('/getTopic') }}",
            type: "POST",
            data: {
                "_token": "{{ csrf_token() }}",
                "category_id": category_id
            },
            success: function(data){
                if(data.status == 1)
                {
                    data.data.forEach(element => {
                        $("#topic").append("<option value='"+element.id+"'>"+element.name+"</option>");
                    });
                }
                else
                {
                    $("#topic").append("<option disabled selected> "+ data.message +" </option>");
                }
            }
        });
    });


        CKEDITOR.replace( 'editor' );

        if(localStorage.getItem("theme") == "dark")
        {
            CKEDITOR.addCss('.cke_editable { background-color: black; color: white }');
        }

</script>


@include("include.message")