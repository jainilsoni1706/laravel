<!doctype html>
<html lang="en">


<!-- Mirrored from assiagroupe.site/demo/html/template/oredoo/Oredoo/index-8.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 14 Aug 2022 09:42:24 GMT -->
<head>
    <!-- Meta -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- favicon -->
    <link rel="icon" sizes="16x16" href="assets/img/favicon.png">

    <title> Solution Finder </title>
  
    <!-- CSS Plugins -->
    <link rel="stylesheet" href="{{Solution::css('bootstrap.min')}}">
    <link rel="stylesheet" href="{{Solution::css('owl.carousel')}}">
    <link rel="stylesheet" href="{{Solution::css('line-awesome.min')}}">
    <link rel="stylesheet" href="{{Solution::css('fontawesome')}}">

    <!-- main style -->
    <link rel="stylesheet" href="{{Solution::css('style')}}">
    <link rel="stylesheet" href="{{Solution::css('custom')}}">
</head>

<body>
    <!--loading -->
    <div class="loader">
        <div class="loader-element"></div>
    </div>

    <!-- Header-->
    <header class="header navbar-expand-lg fixed-top ">
        <div class="container-wrap2 ">
            <div class="header-area">
                <!--logo-->
                <div class="logo">
                    <a href="index.html">
                        <img src="assets/img/logo/logo-dark.png" alt="" class="logo-dark">
                        <img src="assets/img/logo/logo-white.png" alt="" class="logo-white">
                    </a>
                </div>
                <!--/-->
                <div class="header-navbar">
                    <nav class="navbar">
                        <!--navbar-collapse-->
                        <div class="collapse navbar-collapse" id="main_nav">
                            <ul class="navbar-nav ">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle active" href="{{ url('/home') }}"> Home </a>
                                </li>

                                <li class="nav-item dropdown">
                                    <a class="nav-link  dropdown-toggle" href="{{ url('/upload') }}"> Upload Solution </a>
                                </li>
                        
                                <li class="nav-item dropdown">
                                    <a class="nav-link  dropdown-toggle " href="{{ url("/mysolution") }}"> My Solutions </a>
                                </li>
                            
                                <li class="nav-item dropdown">
                                    <a class="nav-link  dropdown-toggle " href="#" data-toggle="dropdown"> features </a>
                                </li>
                            
                                <li class="nav-item dropdown">
                                    <a class="nav-link  dropdown-toggle " href="#" data-toggle="dropdown"> shop </a>
                                </li>
                            </ul>
                        </div>
                        <!--/-->
                    </nav>
                </div>

                <!--header-right-->
                <div class="header-right ">
                    <!--theme-switch-->
                    <div class="theme-switch-wrapper">
                        <label class="theme-switch" for="checkbox">
                            <input type="checkbox" id="checkbox" />
                            <span class="slider round ">
                                <i class="lar la-sun icon-light"></i>
                                <i class="lar la-moon icon-dark"></i>
                            </span>
                        </label>
                    </div>

                     <!--search-icon-->
                    <div class="search-icon">
                        <i class="las la-search"></i>
                    </div>

                   <!--button-subscribe-->
                    <div class="botton-sub">
                        <div class="btn-subscribe">Wallet : 100</div>
                        <a href="{{ url('/profile') }}" class="btn-subscribe">Profile</a>
                        <a href="{{ url('/logout') }}" class="btn-subscribe">Logout</a>
                    </div>
                    <!--navbar-toggler-->
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main_nav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <!--/-->
                </div>
            </div>
        </div> 
    </header>