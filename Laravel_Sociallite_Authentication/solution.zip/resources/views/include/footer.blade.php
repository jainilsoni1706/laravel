

    <!--Back-to-top-->
    <div class="back">
        <a href="#" class="back-top">
            <i class="las la-long-arrow-alt-up"></i>
        </a>
    </div>
   

    <!--Search-form-->
    <div class="search">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-7 col-md-10 m-auto">
                    <div class="search-width">
                        <button type="button" class="close">
                            <i class="far fa-times"></i>
                        </button>
                        <form class="search-form" action="https://assiagroupe.site/demo/html/template/oredoo/Oredoo/search.html">
                            <input type="search" value="" placeholder="What are you looking for?">
                            <button type="submit" class="search-btn"> search</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="{{Solution::js("jquery.min")}}"></script>
    <script src="{{Solution::js("popper.min")}}"></script>
    <script src="{{Solution::js("bootstrap.min")}}"></script>
    
    <script  src="{{Solution::js("theia-sticky-sidebar")}}"></script>
    <script src="{{Solution::js("ajax-contact")}}"></script>
    <script src="{{Solution::js("owl.carousel.min")}}"></script>
    <script src="{{Solution::js("switch")}}"></script>
    <script src="{{Solution::js("jquery.marquee")}}"></script>

    <script src="{{Solution::js("main")}}"></script>

</body>


</html>