<!doctype html>
<html lang="en">
<head>

    <!-- Meta -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="icon" sizes="16x16" href="assets/img/favicon.png">

    <title> Solution Finder | Register  </title>
  
    <link rel="stylesheet" href="{{Solution::css('bootstrap.min')}}">
    <link rel="stylesheet" href="{{Solution::css('owl.carousel')}}">
    <link rel="stylesheet" href="{{Solution::css('line-awesome.min')}}">
    <link rel="stylesheet" href="{{Solution::css('fontawesome')}}">

    <link rel="stylesheet" href="{{Solution::css('style')}}">
    <link rel="stylesheet" href="{{Solution::css('custom')}}">
</head>

<body>
    <!--loading -->
    <div class="loader">
        <div class="loader-element"></div>
      </div>

    <!--Login-->
    <section class="login">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-8 m-auto">
                    <div class="login-content">
                        <h4>Sign up</h4>
                        <!--form-->              
                        <form action="{{ url('auth/register') }}" class="sign-form widget-form contact_form " method="POST"> 
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Username*" name="username" value="">
                            </div>

                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Email Address*" name="email" value="">
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Phone Number*" name="phone" value="">
                            </div>

                            <div class="form-group">
                                <input type="password" class="form-control" placeholder="Password*" name="password" value="">
                            </div>
                            <div class="sign-controls form-group">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="rememberMe">
                                    <label class="custom-control-label" for="rememberMe">Agree to our <a href="#" class="btn-link">terms & conditions</a> </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn-custom">Sign Up</button>
                            </div>
                            <p class="form-group text-center">Already have an account? <a href="{{ url('/') }}" class="btn-link">Login</a> </p>
                        </form>
                           <!--/-->
                    </div> 
                </div>
             </div>
        </div>
    </section>       

    <!--instagram-->
    <div class="instagram">
        <div class="container-fluid">
            <div class="instagram-area">
                <div class="instagram-list">
                    <div class="instagram-item">
                        <a href="#">
                            <img src="assets/img/instagram/1.jpg" alt="">
                            <div class="icon">
                            <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="assets/img/instagram/2.jpg" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="assets/img/instagram/3.jpg" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="assets/img/instagram/4.jpg" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="assets/img/instagram/5.jpg" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="instagram-item">
                        <a href="#">
                            <img src="assets/img/instagram/6.jpg" alt="">
                            <div class="icon">
                                <i class="lab la-instagram"></i>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="{{Solution::js("jquery.min")}}"></script>
    <script src="{{Solution::js("popper.min")}}"></script>
    <script src="{{Solution::js("bootstrap.min")}}"></script>
    
    <script  src="{{Solution::js("theia-sticky-sidebar")}}"></script>
    <script src="{{Solution::js("ajax-contact")}}"></script>
    <script src="{{Solution::js("owl.carousel.min")}}"></script>
    <script src="{{Solution::js("switch")}}"></script>
    <script src="{{Solution::js("jquery.marquee")}}"></script>

    <script src="{{Solution::js("main")}}"></script>

</body>

</html>

@include("include.message")