@include("include.header")

<section class="post-single">
    <div class="container-fluid ">
        <div class="row ">
            <div class="col-lg-12">
                <!--post-single-title-->
                <div class="post-single-body"> 
                    <div class="post-single-title">  
                        <h2> {{ $data->title }} </h2>        
                        <div  class="meta-social">
                            <ul class="entry-meta">
                                <li class="post-author-img"><img src="{{ URL::asset("public/uploads/profile")."/".DB::table("users")->where("id",$data->user_id)->get()->first()->profile }}" alt="profile" style="object-fit:cover;"></li>
                                <li class="post-author"> <a href=""> {{DB::table("users")->where("id",$data->user_id)->get()->first()->username}} </a></li>
                                <li class="entry-cat"> <a href="blog-layout-1.html" class="category-style-1"> <span class="line"></span> {{DB::table("category")->where("id",$data->category_id)->get()->first()->name}} > {{DB::table("topic")->where("id",$data->topic_id)->get()->first()->name}} </a></li>
                                <li class="post-date"> <span class="line"></span> {{ date("F d, Y") }} </li>
                            </ul>
                            <div class="social-media">
                                <ul class="list-inline">
                                    <li> <p>Share :</p></li>
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" >
                                            <i class="fab fa-youtube"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" >
                                            <i class="fab fa-pinterest"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div> 
                        </div>  
                    </div>
                </div>

                <!--post-single-image-->
                <div class="post-single-image">
                    <img src="assets/img/blog/29.jpg" alt="">
                </div>

                <div class="post-single-body">                      
                    <!--post-single-content-->
                    <div class="post-single-content">
                        <p>
                            {{$data->description}}
                        </p>

                    
                        <div>
                            <?php echo $data->content; ?>
                        </div>

                    
                

                        <h4>Author</h4>
                    <!--post-single-author-->
                    <div class="post-single-author ">
                        <div class="authors-info">
                            <div class="image">
                                <a href="" class="image">
                                    <img src="{{ URL::asset("public/uploads/profile")."/".DB::table("users")->where("id",$data->user_id)->get()->first()->profile }}" style="object-fit:cover;width:70px;height:70px;border-radius:50%;">
                                </a>
                            </div>
                            <div class="content">
                            <h4>
                                <?php  
                                if($data->user_id == session()->get("X_Auth_User_ID_SolutionFinder1706"))    
                                {
                                    echo "You";
                                }
                                else
                                {
                                    ?>
                                    {{DB::table("users")->where("id",$data->user_id)->get()->first()->username}}
                                    <?php   
                                }
                            ?>
                            </h4>
                        <p> {{DB::table("users")->where("id",$data->user_id)->get()->first()->bio}}
                        </p>
                              <??> 
                            </div>
                        </div>
                    </div>
                     <!--post-single-Related posts-->
                     <div class="post-single-next-previous">
                        <div class="row ">
                            <?php  $prev = DB::select("SELECT * FROM blog WHERE id!=$data->id ORDER BY RAND() LIMIT 1"); ?>
                            <!--prevvious post-->
                            <div class="col-md-6">
                                <div class="small-post">
                                    <div class="small-post-image">
                                        <a href="{{ url("/read")."/".$prev[0]->solution_id }}">
                                            <img src="{{ URL::asset("public/uploads/thumbnail")."/".$prev[0]->thumbnail }}" alt="...">
                                        </a>
                                    </div>
                    
                                    <div class="small-post-content">
                                    <small>  <a href="{{ url("/read")."/".$prev[0]->solution_id }}"> <i class="las la-arrow-left"></i>Previous post</a></small>
                                    
                                    <p>
                                        <a href="{{ url("/read")."/".$prev[0]->solution_id }}">{{$prev[0]->title}}.</a>
                                    </p>
                                    </div>
                                </div>
                            </div>
                            <!--/-->
                            <?php  $next = DB::select("SELECT * FROM blog WHERE id!=$data->id and id!=".$prev[0]->id." ORDER BY RAND() LIMIT 1");
                            ?>
                            <!--next post-->
                            <div class="col-md-6">
                                <div class="small-post">
                                    <div class="small-post-image">
                                        <a href="{{ url("/read")."/".$next[0]->solution_id }}">
                                            <img src="{{ URL::asset("public/uploads/thumbnail")."/".$next[0]->thumbnail }}" alt="...">
                                        </a>
                                    </div>
                    
                                    <div class="small-post-content">
                                        <small> <a href="post-single.html">Next post <i class="las la-arrow-right"></i></a> </small>
                                        <p>
                                            <a href="{{ url("/read")."/".$next[0]->solution_id }}">{{$next[0]->title}}.</a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!--/-->
                        </div>
                    </div>
                    <!--post-single-Ads-->
                    <div class="post-single-ads ">
                        <div class="ads">
                            <img src="assets/img/ads/ads.jpg" alt="">
                        </div>
                    </div>
                    
                    <!--post-single-comments-->
                    <div class="post-single-comments">
                        <!--Comments-->
                        <h4 >{{DB::table('comment')->where("blog_id",$data->id)->where("status",1)->count()}} Comments</h4>
                        <ul class="comments">


                            @forelse (DB::table("comment")->where('blog_id',$data->id)->where('status',1)->get() as $x)
                            <li class="comment-item pt-0" style="margin-top:20px;">
                                <img src="{{ URL::asset("public/uploads/profile")."/".DB::table("users")->where('id',1)->get()->first()->profile }}" style="object-fit:cover;width:70px;height:70px;border-radius:50%;">
                                <div class="content">
                                    <div class="meta">
                                        <ul class="list-inline">
                                            <li> {{DB::table("users")->where("id",1)->get()->first()->username}} </li>
                                            <li class="slash"></li>
                                            <li>{{ $x->created_at }}</li>
                                        </ul>
                                    </div>
                                    <p>{{$x->body}}
                                    </p>
                                    <p style="padding: 20px;">
                                        Replies <br>
                                        @forelse (DB::table("reply")->where("comment_id",$x->id)->where("status",1)->get() as $r)
                                        <b style="color: blue;">{{ "@".DB::table("users")->where("id",1)->get()->first()->username.":" }}</b> {{$r->body}} <br>                                            
                                        @if($loop->last)
                                        <textarea name="reply" class="form-control" placeholder="Reply to this comment" style="margin-top:20px;"></textarea>                                            
                                        @endif
                                        @empty
                                        <textarea name="reply" class="form-control" placeholder="Reply to this comment"></textarea>                                            
                                        @endforelse
                                    </p>
                                </div>
                            </li>
                            @empty
                            @endforelse

                        </ul>
                        <!--Leave-comments-->
                        <div class="comments-form">
                            <h4 >Leave a Reply</h4>
                            <!--form-->
                            <form class="form " action="{{ url("comment_on_solution") }}" method="POST" id="main_contact_form">@csrf
                                <p>Your email adress will not be published ,Requied fileds are marked*.</p>
                                <div class="alert alert-success contact_msg" style="display: none" role="alert">
                                    Your message was sent successfully.
                                </div>
                                <input type="hidden" name="solution_id" value="{{$data->solution_id}}">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <textarea name="comment" id="message" cols="30" rows="5" class="form-control" placeholder="Message*" required="required"></textarea>
                                        </div>
                                    </div>
                                
                                    <div class="col-lg-12">                                    
                                        <button type="submit" name="submit" class="btn-custom">
                                            Send Comment
                                        </button>
                                    </div> 
                                </div>
                            </form>
                            <!--/-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@include("include.footer")
@include("include.message")

<script src="{{Solution::js("ajax")}}"></script>
<script>

    

</script>