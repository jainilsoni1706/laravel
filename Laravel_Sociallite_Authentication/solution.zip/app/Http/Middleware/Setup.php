<?php

namespace App\Http\Middleware;

use Illuminate\Http\Request;
use Closure;
use DB;

class Setup
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {

        $user_id = session("X_Auth_User_ID_SolutionFinder1706");

        $firstname = DB::table('users')->where('id', $user_id)->get()->first()->username;
        $lastname = DB::table('users')->where('id', $user_id)->get()->first()->lastname;
        $site_email = DB::table('users')->where('id', $user_id)->get()->first()->site_email;
        $gender = DB::table('users')->where('id', $user_id)->get()->first()->gender;
        $dob = DB::table('users')->where('id', $user_id)->get()->first()->dob;
        $occupation = DB::table('users')->where('id', $user_id)->get()->first()->occupation;

        if(isset($firstname) && isset($lastname) && isset($site_email) && isset($gender) && isset($dob) && isset($occupation))
        {
            
        }
        else
        {
            session()->flash("error", "Setup your profile first to go further");
            return redirect('/profile');
        }

        return $next($request);
    }
}
