<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Classes\Solution;
use Socialite;
use Artisan;
use Storage;
use File;
use Mail;
use DB;

class Authentication extends Controller
{
    public function homeView()
    {
        Artisan::call('config:clear');
        Artisan::call('cache:clear');

        return view('index');
    }

    public function profileView()
    {
        $user_id =session()->get('X_Auth_User_ID_SolutionFinder1706');

        $user = DB::table("users")->where("id",$user_id)->get()->first();

        return view('profile',["user"=>$user]);
    }

    //google
    public function redirectToGoogle()
    {
        return Socialite::driver('google')->redirect();
    }

    public function handleGoogleCallback()
    {
        try {
    
            $user = Socialite::driver('google')->user();
     
            $finduser = DB::table('users')->where('google_token', $user->id)->orWhere('email',$user->email)->count();

            if($finduser == 1)
            {
                $getToken = DB::table('users')->where('google_token', $user->id)->orWhere('email',$user->email)->get()->first();

                DB::table("users")->where('email',$user->email)->update([
                    'google_token' => $user->id,
                ]);

                if($getToken->status == 0)
                {
                    session()->flash('error','Your account is deactivated for 30 days. Please contact admin.');
                    return redirect('/');
                }
                else
                {
                    session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
                    session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
                    
                    session()->flash('success',"Logged in Successfully");
                    return redirect('/home');
                }

            }
            else
            {

                $newUser = DB::table('users')->insert([
                    'username' => $user->name,
                    'firstname' => "",
                    'lastname' => "",
                    'email' => $user->email,
                    'google_token' => $user->id,
                    'phone' => isset($user->phone_number) ? $user->phone_number : rand(7000000000,9999999999),
                    'profile' => $user->avatar_original,
                    'password' => Hash::make(12345678),
                ]);

                $getToken = DB::table('users')->orderBy('id','DESC')->get()->first();

                session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
                session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
     
                return redirect('/home');
            }
    
        } catch (Exception $e) {
            dd($e->getMessage());
        }
    }

    //github
    public function redirectToGithub()
    {
        return Socialite::driver('github')->redirect();
    }

    public function handleGithubCallback()
    {
        try {
        
            $user = Socialite::driver('github')->user();
         
            $finduser = DB::table('users')->where('github_token', $user->id)->orWhere('email',$user->email)->count();

            if($finduser == 1)
            {
                $getToken = DB::table('users')->where('github_token', $user->id)->orWhere('email',$user->email)->get()->first();

                DB::table("users")->where('email',$user->email)->update([
                    'github_token' => $user->id,
                ]);

                if($getToken->status == 0)
                {
                    session()->flash('error','Your account is deactivated for 30 days. Please contact admin.');
                    return redirect('/');
                }
                else
                {
                    session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
                    session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
                 
                    session()->flash('success',"Logged in Successfully");
                    return redirect('/home');
                }

            }
            else
            {

                $newUser = DB::table('users')->insert([
                    'username' => $user->name,
                    'firstname' => "",
                    'lastname' => "",
                    'email' => $user->email,
                    'github_token' => $user->id,
                    'phone' => isset($user->phone_number) ? $user->phone_number : rand(7000000000,9999999999),
                    'password' => Hash::make(12345678),
                ]);

                $getToken = DB::table('users')->orderBy('id','DESC')->get()->first();

                session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
                session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
     
                return redirect('/home');
            }
        
        } catch (Exception $e) {
            dd($e->getMessage());
        }
    }

    //facebook
    public function redirectToFacebook()
    {
        return Socialite::driver('facebook')->redirect();
    }

    public function handleFacebookCallback()
    {
        try {
        
            $user = Socialite::driver('facebook')->user();
         
            $finduser = DB::table('users')->where('facebook_token', $user->id)->orWhere('email',$user->email)->count();

            if($finduser == 1)
            {
                $getToken = DB::table('users')->where('facebook_token', $user->id)->orWhere('email',$user->email)->get()->first();

                DB::table("users")->where('email',$user->email)->update([
                    'facebook_token' => $user->id,
                ]);

                if($getToken->status == 0)
                {
                    session()->flash('error','Your account is deactivated for 30 days. Please contact admin.');
                    return redirect('/');
                }
                else
                {
                    session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
                    session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
                 
                    session()->flash('success',"Logged in Successfully");
                    return redirect('/home');
                }

            }
            else
            {

                $newUser = DB::table('users')->insert([
                    'username' => $user->name,
                    'firstname' => "",
                    'lastname' => "",
                    'email' => $user->email,
                    'facebook_token' => $user->id,
                    'phone' => isset($user->phone_number) ? $user->phone_number : rand(7000000000,9999999999),
                    'password' => Hash::make(12345678),
                ]);

                $getToken = DB::table('users')->orderBy('id','DESC')->get()->first();

                session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
                session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
     
                return redirect('/home');
            }
        
        } catch (Exception $e) {
            dd($e->getMessage());
        }
    }

    //twitter
    public function redirectToTwitter()
    {
        return Socialite::driver('twitter')->redirect();
    }

    public function handleTwitterCallback()
    {
        try {
        
            $user = Socialite::driver('twitter')->user();
         
            $finduser = DB::table('users')->where('twitter_token', $user->id)->orWhere('email',$user->email)->count();
            if($finduser == 1)
            {
                $getToken = DB::table('users')->where('twitter_token', $user->id)->orWhere('email',$user->email)->get()->first();

                DB::table("users")->where('email',$user->email)->update([
                    'twitter_token' => $user->id,
                ]);

                if($getToken->status == 0)
                {
                    session()->flash('error','Your account is deactivated for 30 days. Please contact admin.');
                    return redirect('/');
                }
                else
                {
                    session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
                    session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
                    
                    session()->flash('success',"Logged in Successfully");
                    return redirect('/home');
                }

            }
            else
            {

                $newUser = DB::table('users')->insert([
                    'username' => $user->name,
                    'firstname' => "",
                    'lastname' => "",
                    'email' => $user->email,
                    'twitter_token' => $user->id,
                    'phone' => isset($user->phone_number) ? $user->phone_number : rand(7000000000,9999999999),
                    'password' => Hash::make(12345678),
                ]);
                $getToken = DB::table('users')->orderBy('id','DESC')->get()->first();
                session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
                session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
     
                return redirect('/home');
            }
        
        } catch (Exception $e) {
            dd($e->getMessage());
        }
    }

    //instagram
    public function redirectToInstagram()
    {
        return Socialite::driver('instagram')->redirect();
    }

    public function handleInstagramCallback()
    {
        try {
        
            $user = Socialite::driver('instagram')->user();
         
            $finduser = DB::table('users')->where('instagram_token', $user->id)->orWhere('email',$user->email)->count();
            if($finduser == 1)
            {
                $getToken = DB::table('users')->where('instagram_token', $user->id)->orWhere('email',$user->email)->get()->first();

                DB::table("users")->where('email',$user->email)->update([
                    'instagram_token' => $user->id,
                ]);

                if($getToken->status == 0)
                {
                    session()->flash('error','Your account is deactivated for 30 days. Please contact admin.');
                    return redirect('/');
                }
                else
                {
                    session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
                    session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
                    
                    session()->flash('success',"Logged in Successfully");
                    return redirect('/home');
                }

            }
            else
            {

                $newUser = DB::table('users')->insert([
                    'username' => $user->name,
                    'firstname' => "",
                    'lastname' => "",
                    'email' => $user->email,
                    'instagram_token' => $user->id,
                    'phone' => isset($user->phone_number) ? $user->phone_number : rand(7000000000,9999999999),
                    'password' => Hash::make(12345678),
                ]);
                $getToken = DB::table('users')->orderBy('id','DESC')->get()->first();
                session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
                session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
     
                return redirect('/home');
            }
        
        } catch (Exception $e) {
            dd($e->getMessage());
        }
    }

    //linkedin
    public function redirectToLinkedin()
    {
        return Socialite::driver('linkedin')->redirect();
    }

    public function handleLinkedinCallback()
    {
        try {
        
            $user = Socialite::driver('linkedin')->user();
         
            $finduser = DB::table('users')->where('linkedin_token', $user->id)->orWhere('email',$user->email)->count();
            if($finduser == 1)
            {
                $getToken = DB::table('users')->where('linkedin_token', $user->id)->orWhere('email',$user->email)->get()->first();

                DB::table("users")->where('email',$user->email)->update([
                    'linkedin_token' => $user->id,
                ]);

                if($getToken->status == 0)
                {
                    session()->flash('error','Your account is deactivated for 30 days. Please contact admin.');
                    return redirect('/');
                }
                else
                {
                    session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
                    session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
                    
                    session()->flash('success',"Logged in Successfully");
                    return redirect('/home');
                }

            }
            else
            {

                $newUser = DB::table('users')->insert([
                    'username' => $user->name,
                    'firstname' => "",
                    'lastname' => "",
                    'email' => $user->email,
                    'linkedin_token' => $user->id,
                    'phone' => isset($user->phone_number) ? $user->phone_number : rand(7000000000,9999999999),
                    'password' => Hash::make(12345678),
                ]);
                $getToken = DB::table('users')->orderBy('id','DESC')->get()->first();
                session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
                session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
     
                return redirect('/home');
            }
        
        } catch (Exception $e) {
            dd($e->getMessage());
        }
    }

    public function login(Request $request)
    {
        $email = $request->email;
        $password = $request->password;

        $isEmailExist = DB::table('users')->where('email', $email)->count();
        $isUsernameExist = DB::table('users')->where('username', $email)->count();
        $isPhoneExist = DB::table('users')->where('phone', $email)->count();

        if($isEmailExist == 1)
        {
            $user = DB::table('users')->where('email', $email)->get()->first();
            if(Hash::check($password, $user->password))
            {
                if($user->status == 0)
                {
                    session()->flash('error','Your account is deactivated for 30 days. Please contact admin.');
                    return redirect('/');
                }
                else
                {
                    session()->put('X_Auth_User_ID_SolutionFinder1706',$user->id);
                    session()->put('X_Auth_User_Email_SolutionFinder1706',$user->email);

                    session()->flash('success','You are logged in successfully.');
                    return redirect('/home');
                }
            }
            else
            {
                return redirect('/')->with('error', 'Invalid Password');
            }
        }
        else if($isUsernameExist == 1)
        {
            $user = DB::table('users')->where('username', $email)->get()->first();
            if(Hash::check($password, $user->password))
            {
                if($user->status == 0)
                {
                    session()->flash('error','Your account is deactivated for 30 days. Please contact admin.');
                    return redirect('/');
                }
                else
                {
                    session()->put('X_Auth_User_ID_SolutionFinder1706',$user->id);
                    session()->put('X_Auth_User_Email_SolutionFinder1706',$user->email);

                    session()->flash('success','You are logged in successfully.');
                    return redirect('/home');
                }
            }
            else
            {
                return redirect('/')->with('error', 'Invalid Password');
            }
        }
        else if($isPhoneExist == 1)
        {
            $user = DB::table('users')->where('phone', $email)->get()->first();
            if(Hash::check($password, $user->password))
            {
                if($user->status == 0)
                {
                    session()->flash('error','Your account is deactivated for 30 days. Please contact admin.');
                    return redirect('/');
                }
                else
                {
                    session()->put('X_Auth_User_ID_SolutionFinder1706',$user->id);
                    session()->put('X_Auth_User_Email_SolutionFinder1706',$user->email);

                    session()->flash('success','You are logged in successfully.');
                    return redirect('/home');
                }
            }
            else
            {
                return redirect('/')->with('error', 'Invalid Password');
            }
        }
        else
        {
            return redirect('/')->with('error', 'Invalid Credentials');
        }

        
    }

    //gc
    public function register(Request $request)
    {
        
        $email = $request->email;
        $password = $request->password;
        $username = $request->username;
        $phone = $request->phone;

        $isEmailExist = DB::table('users')->where('email', $email)->count();
        $isUsernameExist = DB::table('users')->where('username', $username)->count();
        $isPhoneExist = DB::table('users')->where('phone', $phone)->count();

        if($isEmailExist == 1)
        {
            return redirect('/')->with('error', 'Email already exist');
        }
        else if($isUsernameExist == 1)
        {
            return redirect('/')->with('error', 'Username already exist');
        }
        else if($isPhoneExist == 1)
        {
            return redirect('/')->with('error', 'Phone already exist');
        }
        else
        {
            $newUser = DB::table('users')->insert([
                'username' => $username,
                'firstname' => "",
                'lastname' => "",
                'email' => $email,
                'phone' => $phone,
                'password' => Hash::make($password),
            ]);

            $getToken = DB::table('users')->orderBy('id','DESC')->get()->first();

            session()->put('X_Auth_User_ID_SolutionFinder1706',$getToken->id);
            session()->put('X_Auth_User_Email_SolutionFinder1706',$getToken->email);
     
            return redirect('/home');
        }
    }

    //logout
    public function logout()
    {
        session()->forget('X_Auth_User_ID_SolutionFinder1706');
        session()->forget('X_Auth_User_Email_SolutionFinder1706');

        return redirect('/');
    }

    //disable account for 30 days 
    public function disableAccount()
    {
        $getuser = DB::table('users')->where('id', session()->get('X_Auth_User_ID_SolutionFinder1706'))->get()->first();

        $data = ['frommail' => 'jainilsoni1706@gmail.com', 'tomail' => $getuser->email, 'subject' => "Temporary Account Deactivation","username"=>$getuser->username];

        Mail::send('template.TemporaryAccountDeactivation', $data, function ($message) use ($data)
        {
            $message->to($data['tomail']);
            $message->from($data['frommail']);
            $message->subject($data['subject']);
        });

        $phonenumber = $getuser->phone;

        // $basic  = new \Nexmo\Client\Credentials\Basic(env("NEXMO_KEY"), env("NEXMO_SECRET"));
        // $client = new \Nexmo\Client($basic);
 

        // $message = $client->message()->send([
        //     'to' => "$phonenumber",
        //     'from' => 'Solution Finder',
        //     'text' => 'You have deactivated your account today. Your account will remain deactivated for next 30 days. Thank you for using Solution Finder.'
        // ]);
 
        $user = DB::table('users')->where('id', session()->get('X_Auth_User_ID_SolutionFinder1706'))->update([

            'status' => 0,
            'disable_date' => date("Y-m-d", strtotime("+30 days")),

        ]);


        session()->forget('X_Auth_User_ID_SolutionFinder1706');
        session()->forget('X_Auth_User_Email_SolutionFinder1706');

        session()->flash('success','Your account has deactivated for 30 days Successfully.');
        return redirect('/');
    }

    //edit profile
    public function editProfile(Request $request)
    {
        $id = session()->get('X_Auth_User_ID_SolutionFinder1706');
        $email = session()->get('X_Auth_User_Email_SolutionFinder1706');
        $firstname = $request->firstname;
        $lastname = $request->lastname;
        $siteemail = $request->siteemail;
        $occupation = $request->occupation;
        $address = $request->address;
        $bio = $request->bio;
        $gender = $request->gender;
        $dob = $request->dob;
        $country = $request->country;

        if(!DB::table("users")->where("site_email",$siteemail)->where("id","!=",$id)->count() > 0)
        {

            if(DB::table("category")->where("id",$occupation)->where("status",1)->count() > 0)
            {

                if(DB::table('countries')->where("id",$country)->count() > 0)
                {

                    if(!($gender == 1 || $gender == 2 || $gender == 3))
                    {
                        session()->flash('error', 'Invalid Gender');
                        return redirect('/profile');
                    }

                    $user = DB::table('users')->where('id', $id)->update([
                        'firstname' => isset($firstname) ? $firstname : NULL,
                        'lastname' => isset($lastname) ? $lastname : NULL,
                        'gender' => isset($gender) ? $gender : NULL,
                        'site_email' => isset($siteemail) ? $siteemail : NULL,
                        'occupation' => isset($occupation) ? $occupation : NULL,
                        'address' => isset($address) ? $address : NULL,
                        'bio' => isset($bio) ? $bio : NULL,
                        'dob' => isset($dob) ? date("Y-m-d", strtotime($dob)) : NULL,
                        'country' => isset($country) ? $country : NULL,
                    ]);
                    session()->flash('success','Your profile has been updated successfully.');
                    return redirect('/home');
                }
                else
                {
                    return redirect('/profile');
                    session()->flash('error', 'Invalid Country');
                }
            }
            else
            {
                session()->flash('error','Invalid Category');
                return redirect('/profile');
            }
        }
        else
        {
            session()->flash('error','Site Email already exist');
            return redirect('/profile');
        }

    }


    //controller ends
}
