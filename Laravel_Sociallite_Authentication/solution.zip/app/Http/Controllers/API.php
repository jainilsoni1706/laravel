<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Classes\Solution;
use Socialite;
use Artisan;
use Storage;
use File;
use Mail;
use DB;

class API extends Controller
{
   

    public function login(Request $request)
    {
            $email = $request->email;
            $password = $request->password;

            $isEmailExist = DB::table('users')->where('email', $email)->count();
            $isUsernameExist = DB::table('users')->where('username', $email)->count();
            $isPhoneExist = DB::table('users')->where('phone', $email)->count();

            if($isEmailExist == 1)
            {
                $user = DB::table('users')->where('email', $email)->get()->first();
                if(Hash::check($password, $user->password))
                {
                    if($user->status == 0)
                    {
                        $result['status'] = 0;
                        $result['message'] = "Your account is deactivated for 30 days. Please contact admin";
                    }
                    else
                    {
                        $result['data'] = DB::table("users")->where("email",$email)->get()->first();
                        $result['status'] = 1;
                        $result['message'] = "You are logged in successfully";
                    }
                }
                else
                {
                        $result['status'] = 0;
                        $result['message'] = "Invalid Password";
                }
            }
            else if($isUsernameExist == 1)
            {
                $user = DB::table('users')->where('username', $email)->get()->first();
                if(Hash::check($password, $user->password))
                {
                    if($user->status == 0)
                    {
                        $result['status'] = 0;
                        $result['message'] = "Your account is deactivated for 30 days. Please contact admin";
                    }
                    else
                    {
                        $result['data'] = DB::table("users")->where("username",$email)->get()->first();
                        $result['status'] = 1;
                        $result['message'] = "You are logged in successfully";
                    }
                }
                else
                {
                        $result['status'] = 0;
                        $result['message'] = "Invalid Password";
                }
            }
            else if($isPhoneExist == 1)
            {
                $user = DB::table('users')->where('phone', $email)->get()->first();
                if(Hash::check($password, $user->password))
                {
                    if($user->status == 0)
                    {
                        $result['status'] = 0;
                        $result['message'] = "Your account is deactivated for 30 days. Please contact admin";
                    }
                    else
                    {
                        $result['data'] = DB::table("users")->where("phone",$email)->get()->first();
                        $result['status'] = 1;
                        $result['message'] = "You are logged in successfully";
                    }
                }
                else
                {
                        $result['status'] = 0;
                        $result['message'] = "Invalid Password";
                }
            }
            else
            {
                        $result['status'] = 0;
                        $result['message'] = "Invalid Arguments";
            }


            return response()->json($result);
    } 


    public function signup(Request $request)
    {
        $email = $request->email;
        $password = $request->password;
        $username = $request->username;
        $phone = $request->phone;

        $isEmailExist = DB::table('users')->where('email', $email)->count();
        $isUsernameExist = DB::table('users')->where('username', $username)->count();
        $isPhoneExist = DB::table('users')->where('phone', $phone)->count();

        if($isEmailExist == 1)
        {
            $result['status'] = 0;
            $result['message'] = "Email Already Exist";
        }
        else if($isUsernameExist == 1)
        {
            $result['status'] = 0;
            $result['message'] = "Username Already Exist";
        }
        else if($isPhoneExist == 1)
        {
            $result['status'] = 0;
            $result['message'] = "Phone Already Exist";
        }
        else
        {
            $newUser = DB::table('users')->insert([
                'username' => $username,
                'firstname' => "",
                'lastname' => "",
                'email' => $email,
                'phone' => $phone,
                'password' => Hash::make($password),
            ]);

            $result['data'] = DB::table("users")->where("email",$email)->get()->first();
            $result['status'] = 1;
            $result['message'] = "Success";
        }

        return response()->json($result);
    }

    public function get_all_user()
    {
        $count = DB::table("users")->count();

        if($count > 0)
        {
            $result['data'] = DB::table("users")->get();
            $result['status'] = 0;
            $result['message'] = "No user found";            
        }
        else
        {
            $result['status'] = 0;
            $result['message'] = "No user found";
        }

        return response()->json($result);
    }

    public function deleteUser(Request $request)
    {
        $id = $request->id;

        if(isset($id))
        {
            if(DB::table("users")->where("id",$id)->count() > 0)
            {

                DB::table("users")->where("id",$id)->delete();

                $result['status'] = 1;
                $result['message'] = "User deleted successfully";                
            }
            else
            {
                $result['status'] = 0;
                $result['message'] = "User not exist";
            }
        }
        else
        {
            $result['status'] = 0;
            $result['message'] = "Enter an user id";
        }

        return response()->json($result);
    }

//controller ends here
}
