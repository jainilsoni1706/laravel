<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Classes\Solution;
use Socialite;
use Artisan;
use Storage;
use File;
use Mail;
use DB;

class Management extends Controller
{
    public function uploadSolution()
    {
        return view('uploadSolution');
    }

    public function getTopic(Request $request)
    {
        $category_id = $request->category_id;

        if(isset($request->category_id) && DB::table("category")->where("id",$category_id)->count() > 0)
        {
            if(DB::table("topic")->where('category_id',$category_id)->where('status',1)->count() > 0)
            {
                $result['data'] = DB::table("topic")->where('category_id',$category_id)->where('status',1)->get();
                $result['status'] = 1;
                $result['message'] = "Success";
            }
            else
            {
                $result['status'] = 0;
                $result['message'] = "This category has no topic";                
            }
        }
        else
        {
            $result['status'] = 0;
            $result['message'] = "Invalid Category";
        }

        return response()->json($result);
    }

    public function uploadSolutionX(Request $request)
    {

        $category_id = $request->category;
        $topic_id = $request->topic;
        $title = $request->title;
        $description = $request->description;
        $thumbnail = $request->thumbnail;
        $content = $request->editor;
        $prime = $request->prime;
        $coin = $request->coin;
        $solution_id = Str::random(20);


        $user_id = session()->get('X_Auth_User_ID_SolutionFinder1706');


        if(isset($category_id) && isset($topic_id) && isset($title) && isset($description) && isset($content))
        {
            if(DB::table('category')->where('id',$category_id)->where('status',1)->count() > 0 && DB::table('topic')->where('id',$topic_id)->where('category_id',$category_id)->where('status',1)->count() > 0)
            {
                if($request->hasFile('thumbnail'))
                {
                    $extension = $request->file('thumbnail')->getClientOriginalExtension();

                    if($extension == "jpg" || $extension == "png" || $extension == "jpeg" || $extension == "gif")
                    {
                        $file = $request->file('thumbnail');
                        $thumbnail = "SF1001".time().'.'.$file->getClientOriginalExtension();
                        $file->move(public_path("uploads/thumbnail"), $thumbnail);
                    }
                    else
                    {
                        session()->flash('error', 'Thumbnail must be image');
                        return redirect('/upload');
                    }
                }
                else
                {
                    $thumbnail = "thumbnail.png";
                }

                if(!($prime == 0 || $prime == 1))
                {
                    session()->flash('error', 'Something went wrong');
                    return redirect('/upload');
                }

                if($prime == 0)
                {
                    if($coin > 0)
                    {
                        session()->flash('error', 'Free Solution cannot have coin');
                        return redirect('/upload');
                    }
                }
                else
                {
                    if($coin <= 0)
                    {
                        session()->flash('error', 'Prime Solution must have coin');
                        return redirect('/upload');
                    }
                }

                DB::table('blog')->insert([
                    'category_id' => $category_id,
                    'topic_id' => $topic_id,
                    'title' => $title,
                    'description' => $description,
                    'user_id' => $user_id,
                    'thumbnail' => $thumbnail,
                    'content' => $content,
                    'solution_id' => $solution_id,
                    'prime' => isset($prime) ? $prime : 0,
                    'coin' => isset($coin) ? $coin : 0,
                    'status' => 1,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);                

                session()->flash('success', 'Solution uploaded successfully');
                return redirect('/upload');

            }
            else
            {
                session()->flash('error', 'Category or Topic is not valid');
                return redirect('/upload');
            }

        }
        else
        {
            session()->flash('error', 'Fill up all fields');
            return redirect('/upload');
        }
    }

    public function mySolutionView()
    {

        $user_id = session()->get('X_Auth_User_ID_SolutionFinder1706');

        $data = DB::table('blog')->where('user_id',$user_id)->where('status',1)->get();

        return view('blog',['data' => $data]);
    }

    public function readSolution(Request $request)
    {

        $solution_id = $request->solution_id;

        $data = DB::table('blog')->where('solution_id',$solution_id)->where('status',1)->first();
                
        return view('readblog',['data' => $data]);
    }

    public function commentOnSolution(Request $request)
    {
        $solution_id = $request->solution_id;
        $comment = $request->comment;

        if($comment != "" && $solution_id != "")
        {
            if(DB::table("blog")->where("solution_id",$solution_id)->count() > 0)
            {
                DB::table("comment")->insert([
                    'body' => $comment,
                    'user_id' => session('X_Auth_User_ID_SolutionFinder1706'),
                    'blog_id' => DB::table("blog")->where("solution_id",$solution_id)->get()->first()->id,
                    'created_at' => date("Y-m-d H:i:s")
                ]);

                session()->flash("error", "Solution does not exist");
                return back();                
            }
            else
            {
                session()->flash("error", "Solution does not exist");
                return back();                
            }
        }
        else
        {
            session()->flash("error", "Fill up all fields");
            return back();
        }

    }
}
