<?php

namespace App\Classes;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Storage;
use File;
use View;
use Mail;
use URL;
use DB;


class Solution
{

    public function template($name)
    {
        $view = View::make('profile');
        $view->nest($name, $name);
        $view->nest('profile', 'profile');
        
        return $view;
    }    

    public function css($parameter)
    {
        return URL::asset("public/assets/css/$parameter.css");
    }

    public function js($parameter)
    {
        return URL::asset("public/assets/js/$parameter.js");
    }

    public function img($parameter)
    {
        return URL::asset("public/assets/img/$parameter");
    }

    public function sendMail($to, $subject, $template, $data)
    {
        Mail::send($template, $data, function($message) use ($to, $subject) {
            $message->to($to)->subject($subject);
        });
    }

    
    public function timeAgo($time)
    {
        $time_difference = time() - $time;

        if( $time_difference < 1 ) { return 'less than 1 second ago'; }
        $condition = array( 12 * 30 * 24 * 60 * 60 =>  'year',
                    30 * 24 * 60 * 60       =>  'month',
                    24 * 60 * 60            =>  'day',
                    60 * 60                 =>  'hour',
                    60                      =>  'minute',
                    1                       =>  'second'
        );

        foreach( $condition as $secs => $str )
        {
            $d = $time_difference / $secs;

            if( $d >= 1 )
            {
                $t = round( $d );
                return 'about ' . $t . ' ' . $str . ( $t > 1 ? 's' : '' ) . ' ago';
            }
        }
}
    

}