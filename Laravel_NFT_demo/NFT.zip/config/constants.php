<?php


//declare your constants here


return [
    "page_title" => "Skynet NFT Exchanges",
];