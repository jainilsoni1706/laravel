<?php


namespace App\Helpers;

use DB;
use Str;
use URL;
use File;
use Mail;
use Storage;


class Bidder
{

//create a bide for usee

public function Bid($array)
{
    if($array['user_id'] != '' && $array['nft_id'] != '' && $array['nft_token'] != '' && $array['coin'] != '' && $array['current_price'] != '')
    {

        $getUser = DB::table('user')->where('id',$array['user_id'])->where('status',1)->count();

        if($getUser == 1)
        {
            $getNFT = DB::table('nft')->where('id',$array['nft_id'])->where('nft_token',$array['nft_token'])->where('status',1)->where('activation',1)->count();

            if($getNFT == 1)
            {
               $getTotalBidCoin = DB::table('nft')->where('id',$array['nft_id'])->where('nft_token',$array['nft_token'])->where('status',1)->where('activation',1)->get()->first();
               $getUserCoin = DB::table('user')->where('id',$array['user_id'])->where('status',1)->get()->first();

                if($getTotalBidCoin->highest_coin == "" || $getTotalBidCoin->highest_coin == null || $getTotalBidCoin->highest_coin == 0 || $getTotalBidCoin->highest_coin == "0")
                {

                    if($getUserCoin->coin >= $array['current_price'])
                    {
                        if(intval($array['coin']))
                        {
                            DB::table("bidder")->insert([
                                "user_id" => $array['user_id'],
                                "nft_id" => $array['nft_id'],
                                "nft_token" => $array['nft_token'],
                                "coin" => $array['current_price'],
                            ]);

                            DB::table('user')->where('id',$array['user_id'])->where('status',1)->update([
                                'coin' => $getUserCoin->coin - $array['current_price'],
                            ]);
                        
                            DB::table('nft')->where('id',$array['nft_id'])->where('nft_token',$array['nft_token'])->where('status',1)->where('activation',1)->update([
                                'highest_coin' => $array['current_price'],
                            ]);

                            return "3";                                        
                            
                        }
                        else
                        {
                            return "enter valid coin";                
                        }
                    }
                    else
                    {
                        return "4";                                        
                    }

                }
                else
                {
                    if($getUserCoin->coin >= $getTotalBidCoin->highest_coin)
                    {
                        $HaveIEverBidCount = DB::table("bidder")->where('user_id',$array['user_id'])->where('nft_id',$array['nft_id'])->where('nft_token',$array['nft_token'])->where('status',1)->count();

                        if($HaveIEverBidCount > 0)
                        {
                            $HaveIEverBid = DB::table("bidder")->where('user_id',$array['user_id'])->where('nft_id',$array['nft_id'])->where('nft_token',$array['nft_token'])->where('status',1)->orderBy("id","DESC")->get()->first();

                            $getCoinIhaveTOGiveNow = $getTotalBidCoin->highest_coin - $HaveIEverBid->coin;
                            $getCoinIhaveTOGiveNow += 100;

                            DB::table("bidder")->insert([
                                "user_id" => $array['user_id'],
                                "nft_id" => $array['nft_id'],
                                "nft_token" => $array['nft_token'],
                                "coin" => $getCoinIhaveTOGiveNow,
                            ]);
                        
                            DB::table('nft')->where('id',$array['nft_id'])->where('nft_token',$array['nft_token'])->where('status',1)->where('activation',1)->update([
                                'highest_coin' => $getTotalBidCoin->highest_coin + 100,
                            ]);

                            DB::table('user')->where('id',$array['user_id'])->where('status',1)->update([
                                'coin' => $getUserCoin->coin - $getCoinIhaveTOGiveNow,
                            ]);

                            return "3";                                        

                        }
                        else
                        {
                            DB::table("bidder")->insert([
                                "user_id" => $array['user_id'],
                                "nft_id" => $array['nft_id'],
                                "nft_token" => $array['nft_token'],
                                "coin" => $array['current_price'] + 100,
                            ]);
                        
                            DB::table('nft')->where('id',$array['nft_id'])->where('nft_token',$array['nft_token'])->where('status',1)->where('activation',1)->update([
                                'highest_coin' => $array['current_price'] + 100,
                            ]);

                            DB::table('user')->where('id',$array['user_id'])->where('status',1)->update([
                                'coin' => $getUserCoin->coin - ($array['current_price'] + 100),
                            ]);

                            return "3";                                        
                        }

                    }
                    else
                    {
                        return "4";                                        
                    }
                }

            }
            else
            {
                return "2";                
            }
        }
        else
        {
            return "2";
        }
    }
    else
    {
        return "1";
    }
}


    //controller ends here
}


// 1 == All fields are empty
// 2 == not found
// 3 == success
// 4 == no coin
// 5 == wrong input value
