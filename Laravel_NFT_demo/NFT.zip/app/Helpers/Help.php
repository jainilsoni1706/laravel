<?php


namespace App\Helpers;

use DB;
use Str;
use URL;
use File;
use Mail;
use Storage;

class Help
{

    //css helper function
    public function css($parameter)
    {
        return URL::asset("public/assets/css/$parameter");
    }

    //js helper function
    public function js($parameter)
    {
        return URL::asset("public/assets/js/$parameter");
    }

    //image helper function
    public function image($parameter)
    {
        return URL::asset("public/assets/images/$parameter");
    }

    //page title constant
    public function title($parameter)
    {
        return config("constants.page_title"." | ".$parameter);
    }

    //referal code generator
    public function referal($parameter)
    {
        if(strlen($parameter) == 1)
        {
            return substr($parameter,0,1) . Str::random(9);
        }
        elseif(strlen($parameter) == 2)
        {
            return substr($parameter,0,2) . Str::random(8);
        }
        else
        {
            return substr($parameter,0,3) . Str::random(7);
        }
    }

    //token generator
    public function token($parameter)
    {
        return Str::random($parameter);
    }

    //get ip address
    public function ip()
    {
        return $_SERVER['REMOTE_ADDR'];
    }

    //set session
    public function setSession($parameter)
    {
        session()->put($parameter);
    }

    //unset session
    public function unsetSession()
    {
        session()->flush();
    }

    //unset single session
    public function unsetOneSession($parameter)
    {
        session()->pull($parameter);
    }

    //user data getter
    public function user()
    {
        return DB::table("user")->where("id",session('NFTuserID'))->where("email",session("NFTuserEmail"))->where('id',session("NFTuserID"))->get()->first();        
    }

    //image for nft
    public function NFTI($parameter)
    {
        return URL::asset("public/assets/nft/$parameter");
    }


    //contain letter or not
    public function containLetter($letter,$sentence)
    {
        $label = "false";

        for($i = 0; $i < strlen($sentence); $i++)
        {
            if($sentence[$i] == $letter)
            {
                $label = "true";
                return $label;
            }
        }

    }

    //get my coin

    public function balance()
    {
        $balance =  DB::table("user")->where("id",session('NFTuserID'))->where("email",session("NFTuserEmail"))->where('id',session("NFTuserID"))->get()->first();        

        return $balance->coin;
    }


    //user profile
    public function userProfile()
    {

        $profile =  DB::table("user")->where("id",session('NFTuserID'))->where("email",session("NFTuserEmail"))->where('id',session("NFTuserID"))->get()->first();                

        return URL::asset("public/assets/profile/$profile->profile");
    }


    //user profile path
    public function profile($parameter)
    {

        $profile =  DB::table("user")->where("id",session('NFTuserID'))->where("email",session("NFTuserEmail"))->where('id',session("NFTuserID"))->get()->first();                

        return URL::asset("public/assets/profile/$parameter");
    }


    //helper controller ends here
}