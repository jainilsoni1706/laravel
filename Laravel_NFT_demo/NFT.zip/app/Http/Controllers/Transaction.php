<?php

namespace App\Http\Controllers;

use DB;
use Str;
use Mail;
use File;
use Help;
use Bidder;
use Storage;
use Socialite;
use App\Models\AppUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class Transaction extends Controller
{
    function createNFT(Request $request)
    {
        $user_id = DB::table('user')->where('id',session("NFTuserID"))->where('email',session("NFTuserEmail"))->where('phone',session("NFTuserPhone"))->get()->first();
        
        $nft_token = Help::token(15);
        $expire_bid = Date("Y-m-d",strtotime($request->nftexpire));
        $img1 = "";
        $img2 = "";
        $img3 = "";
        $title = $request->nftname;
        $coin = $request->nftprice;
        $category = isset($request->category) ? $request->category : 1;
        $prime = 0;
        $description = $request->nftdesc;
        $count = 0;

        if($request->prime == 1)
        {
            $prime = 1;
        }

        if(!(intval($category)))
        {
            session()->flash('error','Do not mess with form...!!!');
            return back();
        }

        foreach ($request->file('files') as $val) 
        {
            $file = $val;
            $name = rand(9999,999999).time().".".$file->extension();
            $file->move(public_path("assets/nft"),$name);            
            $count++;

            if($count == 1)
            {
                $img1 = $name;
            }
            else if($count == 2)
            {
                $img2 = $name;
            }
            else
            {
                $img3 = $name;
            }

        }

        if($request->nftexpire != '' && $request->nftname != '' && $request->nftprice != '' && $request->category != '' && $request->nftdesc != '' && $request->hasFile('files'))
        {
            DB::table("nft")->insert([
                'nft_token' => $nft_token,
                'user_id' => $user_id->id,
                'expire' => $expire_bid,
                'image1' => $img1,
                'image2' => $img2,
                'image3' => $img3,
                'title' => $title,
                'coin' => $coin,
                'highest_coin' => 0,
                'category' => 0,
                'description' => $description,
                'for_prime' => $prime,
                'activation' => 1
            ]);

            session()->flash('success','Your NFT Listed as an Auction...!!!');
            return redirect('/home');
        }
        else
        {
            session()->flash('error','Fill up the all details to sell a NFT...!!!');
            return back();
        }

    }



    //bid on nft
    function BidOnNft(Request $request)
    {
        $data = [
            'user_id' => $request->user_id,
            'nft_id' => $request->nft_id,
            'nft_token' => $request->nft_token,
            'coin' => $request->coin,
            'current_price' => $request->current_price,
        ];

        // dd($data);

        $bid = Bidder::bid($data);

        
    if($bid == 3)
    {

        $get_nft_bidder_name = DB::table('nft')->where('id',$request->nft_id)->where('nft_token',$request->nft_token)->where('status',1)->get()->first();

        DB::table('notifications')->insert([
            'user_id' => $get_nft_bidder_name->user_id,
            'label' => 5,
            'message' => "$get_nft_bidder_name->username bade on your NFT ($get_nft_bidder_name->title) on ".date('d-m-Y H:i'),
        ]);


        session()->flash('success','Bid on NFT Successfully');
        return back();
    }
    else if($bid == 2)
    {
        session()->flash('error','Id Not Found');
        return back();
    }
    else if($bid == 1)
    {
        session()->flash('error','All fields are Empty');
        return back();
    }
    else if($bid == 4)
    {
        session()->flash('error','You do not have sufficient coin');
        return back();
    }
    else if($bid == 5)
    {
        session()->flash('error','Invalid input');
        return back();
    }

    }



    //controller ends here
}

    // 1 == All fields are empty
    // 2 == not found
    // 3 == success
    // 4 == no coin
    // 5 == wrong input value
