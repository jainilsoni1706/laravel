<?php

namespace App\Http\Controllers;

use DB;
use Str;
use Mail;
use File;
use Help;
use Bidder;
use Storage;
use Socialite;
use App\Models\AppUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class Authentication extends Controller
{
    //Authentication Controller Starts Here

    //login for user
    function login(Request $request)
    {
        $login_token = Help::token(30);
        $ip = Help::ip();

        if($request->email != '' && $request->password != '')
        {
            $FindorFailEmail = DB::table('user')->where('email',$request->email)->count();

            if($FindorFailEmail > 0 && $FindorFailEmail == 1)
            {
                $getEmail = DB::table('user')->where('email',$request->email)->get()->first();

                if(Hash::check($request->password,$getEmail->password))
                {

                    $FindorFailStatus = DB::table('user')->where('email',$request->email)->where('status',1)->count();

                    if($FindorFailStatus > 0 && $FindorFailStatus == 1)
                    {
                        $session = [
                            "NFTuserID" => $getEmail->id,
                            "NFTuserEmail" => $getEmail->email,
                            "NFTuserPhone" => $getEmail->phone,
                        ];
    
                        Help::setSession($session);

                        DB::table('user')->where('email',$request->email)->where('status',1)->update([
                            'token1' => $login_token,
                            'ip' => $ip,
                        ]);

                        DB::table('notifications')->insert([
                            'user_id' => $getEmail->id,
                            'label' => 2,
                            'message' => "You have logged in on ".date("d-m-Y H:i")." \n IP: $ip ",
                        ]);
    
                        session()->flash("success","Logged in Successfully...!!!");
                        return redirect("/home");                       
                    }
                    else
                    {
                        session()->flash("error","Your account has not activated yet...!!!");
                        return redirect("/");   
                    }

                }
                else
                {
                    session()->flash("error","Incorrect Password...!!!");
                    return redirect("/");   
                }

            }
            else
            {
                session()->flash("error","Incorrect Email Adress...!!!");
                return redirect("/");   
            }

        }
        else
        {
            session()->flash("error","Fill up the details to Login...!!!");
            return redirect("/");   
        }

    }

    //register for user
    function register(Request $request)
    {
        $referal = Help::referal($request->username);
        $login_token = Help::token(30);
        $ip = Help::ip();
        $hash = Hash::make($request->password);
        $refpoint = 0;
        $referer = 0;
        $refered = 0;
        
        $isUsernameExist = DB::table("user")->where("username",$request->username)->count();

        if($isUsernameExist != 1)
        {
            $isEmailExist = DB::table("user")->where("email",$request->email)->count();

            if($isEmailExist != 1)
            {
                $isPhoneExist = DB::table("user")->where("phone",$request->phone)->count();
    
                if($isPhoneExist != 1)
                {

                    if($request->referal != '')
                    {
                        $referalCheck = DB::table('user')->where('referal',$request->referal)->where('status',1)->count();

                        if($referalCheck == 1)
                        {

                            $getReferer = DB::table('user')->where('referal',$request->referal)->where('status',1)->get()->first();
                            DB::table('user')->where('referal',$request->referal)->where('status',1)->update([
                                'point' => $getReferer->point + 1000
                            ]);

                            $refpoint = 1000;
                            $referer = $getReferer->id;
                            $refered = 1;
 
                            DB::table('notifications')->insert([
                                'user_id' => $getReferer->id,
                                'label' => 12,
                                'message' => "You referal code used by $request->username ".date("d-m-Y H:i")." \n You earned 1000 Point ",
                            ]);

                        }
                        else
                        {
                            session()->flash("error","Invalid referal code...!!!");
                            return redirect("/signup");
                        }
                    }

                    $image = rand(1,15);


                    $refpoint = $refpoint + 50;

                    $table = new AppUsers;
                    $table->username = $request->username;
                    $table->firstname = $request->firstname;
                    $table->lastname = $request->lastname;
                    $table->phone = $request->phone;
                    $table->email = $request->email;
                    $table->password = $hash;
                    $table->referal = $referal;
                    $table->token1 = $login_token;
                    $table->point = $refpoint;
                    $table->status = 1;
                    $table->profile = "client$image.png";
                    $table->referer = $referer;
                    $table->ip = $ip;
                    $table->save();
            


                    $findUser = DB::table("user")->where("password",$hash)->where("referal",$referal)->get()->first();
            
                    $session = [
                        "NFTuserID" => $findUser->id,
                        "NFTuserEmail" => $findUser->email,
                        "NFTuserPhone" => $findUser->phone,
                    ];

                    Help::setSession($session);

                    DB::table('notifications')->insert([
                        'user_id' => $findUser->id,
                        'label' => 1,
                        'message' => "You have created a new account on ".date("d-m-Y H:i")." with \n IP: $ip ",
                    ]);

                    //add referal points credit history
                    if($refered == 1)
                    {
                        DB::table('point')->insert([
                            'user_id' => $findUser->id,
                            'type' => 2,
                            'point' => 450, 
                        ]);                        
                    }

                    DB::table('point')->insert([
                        'user_id' => $findUser->id,
                        'type' => 1,
                        'point' => 50,
                    ]);
            
                    session()->flash("success","Signup Successfully...!!!");
                    return redirect("/home");
                }
                else
                {
                    session()->flash("error","Phone Number already exists...!!!");
                    return redirect("/signup");
                }
            }
            else
            {
                session()->flash("error","Email Address already exists...!!!");
                return redirect("/signup");
            }
        }
        else
        {
            session()->flash("error","Username already exists...!!!");
            return redirect("/signup");   
        }

    }


    //logout
    function logout()
    {
        if(session()->has("NFTuserID") && session()->has("NFTuserEmail") && session()->has("NFTuserPhone"))
        {


            DB::table('notifications')->insert([
                'user_id' => session("NFTuserID"),
                'label' => 3,
                'message' => "You have logged out on ".date("d-m-Y H:i")." \n IP: ".Help::ip(),
            ]);

            Help::unsetSession();

            session()->flash("success","Logged out successfully...!!!");
            return redirect("/");
        }
        else
        {

            Help::unsetSession();

            session()->flash("error","Something went wrong please try again...!!!");
            return redirect("/");
        }
    }

    //referal code checker

    function checkReferalCode(Request $request)
    {
        $referal = DB::table('user')->where('referal',$request->referal)->where('status',1)->count();

        if($referal == 1)
        {
            $data['status'] = 1;
            $data['message'] = "Referal Code Applied Successfully";
        }
        else
        {
            $data['status'] = 0;
            $data['message'] = "Referal Code is Invalid";
        }

        return response()->json($data);

    }


    //Authentication Controller Ends Here
}
