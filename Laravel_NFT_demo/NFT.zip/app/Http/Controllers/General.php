<?php

namespace App\Http\Controllers;

use DB;
use Str;
use Mail;
use File;
use Help;
use Bidder;
use Storage;
use Socialite;
use App\Models\AppUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class General extends Controller
{
    //login view method
    function loginView()
    {
        return view('login');    
    }

    //signup view method
    function signupView()
    {
        return view('sign-up');
    }
    
    //edit profile view method
    public function profileView()
    {
        return view('edit-profile');
    }

    //home view method
    function homeView()
    {   
        $user_id = DB::table('user')->where('id',session("NFTuserID"))->where('email',session("NFTuserEmail"))->where('phone',session("NFTuserPhone"))->get()->first();

        $data = DB::table('nft')->where('status',1)->where('activation',1)->where('for_prime',0)->where('user_id','!=',$user_id->id)->get();

        $total = DB::table('user')->where('status',1)->count();

        $today_date = date("Y-m-d");

        //give to those user who bid highest on nft


        $get_all_nft_list = DB::table('nft')->where('status',1)->where('activation',1)->where('highest_coin',"!=",0)->get();
        
        foreach($get_all_nft_list as $nft)
        {
            if(Date("Y-m-d",strtotime($today_date)) > Date("Y-m-d",strtotime($nft->expire)))
            {

                if(DB::table('bidder')->where('nft_id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->count() > 0)
                {
                $get_highest_nft = $nft->highest_coin;                

                $get_winner = DB::table('bidder')->where('nft_id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->groupBy('user_id')->sum('coin');
                $get_winner_user_id = DB::select("select user_id,nft_token,sum(coin) from bidder group by user_id order by coin desc limit 1");

                if($get_highest_nft == $get_winner)
                {

                    DB::table('collection')->insert([
                        'user_id' => $get_winner_user_id[0]->user_id,
                        'bought_from' => $nft->user_id,
                        'nft_token' => $nft->nft_token,
                        'image1' => $nft->image1,
                        'image2' => $nft->image2,
                        'image3' => $nft->image3,
                        'title' => $nft->title,
                        'price' => $get_highest_nft,
                        'category' => $nft->category,
                        'is_prime' => $nft->for_prime,
                        'created_at' => Date("Y-m-d H:i:s"),
                        'bought_date' => date("Y-m-d",strtotime($nft->expire."+1 days")),
                    ]);


                    DB::table('notifications')->insert([
                        'user_id' => $nft->user_id,
                        'label' => 7,
                        'message' => "NFT you have Registered for Auction is Won By ".$get_winner_user_id[0]->username." on ".date("Y-m-d",strtotime($nft->expire."+1 days"))." \n You earned $get_highest_nft Point ",
                    ]);

                    DB::table('nft')->where('id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->where('activation',1)->delete();         
                    
                    DB::table('bidder')->where('nft_id',$nft->id)->where('nft_token',$nft->nft_token)->delete();

                    DB::table('user')->where('id',$get_winner_user_id[0]->user_id)->where('status',1)->update([
                        'bought' => DB::table('user')->where('id',$get_winner_user_id[0]->user_id)->get()->first()->bought + 1,
                    ]);

                    DB::table('user')->where('id',$nft->user_id)->where('status',1)->update([
                        'sold' => DB::table('user')->where('id',$nft->user_id)->get()->first()->sold + 1,
                    ]);
                }

                }
                else
                {
                    $failed = $nft->failed;

                    if($nft->failed == "0" || $nft->failed == 0)
                    {
                        DB::table('nft')->where('id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->where('activation',1)->update([
                            'status' => 0,
                            'activation' => 0,
                            'highest_coin' => 0,
                            'highest_coin' => 0,
                            'expire' => '',
                            'failed' => 1,
                        ]);


                        DB::table('notifications')->insert([
                            'user_id' => $nft->user_id,
                            'label' => 6,
                            'message' => "NFT you have Registered for Auction is Deactivated Because No one bade on it",
                        ]);

                        DB::table('bidder')->where('nft_id',$nft->id)->where('nft_token',$nft->nft_token)->delete();
                    }
                    else
                    {

                        DB::table('nft')->where('id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->where('activation',1)->update([
                            'status' => 0,
                            'activation' => 0,
                            'highest_coin' => 0,
                            'highest_coin' => 0,
                            'expire' => '',
                            'failed' => $failed + 1,
                        ]);

                        DB::table('notifications')->insert([
                            'user_id' => $nft->user_id,
                            'label' => 6,
                            'message' => "NFT you have Registered for Auction is Deactivated Because No one bade on it",
                        ]);

                        DB::table('bidder')->where('nft_id',$nft->id)->where('nft_token',$nft->nft_token)->delete();

                        DB::table('nft')->where('id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->where('failed',">",3)->where('activation',1)->get();

                    }
                }

            }
        }


        $get_list_of_nft_again = DB::table('nft')->where('status',1)->where('activation',1)->get();

        foreach($get_list_of_nft_again as $nft)
        {

            if(Date("Y-m-d",strtotime($today_date)) > Date("Y-m-d",strtotime($nft->expire)))
            {
                $failed = $nft->failed;

                if($nft->failed == "0" || $nft->failed == 0)
                {
                    DB::table('nft')->where('id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->where('activation',1)->update([
                        'status' => 0,
                        'activation' => 0,
                        'highest_coin' => 0,
                        'highest_coin' => 0,
                        'expire' => '',
                        'failed' => 1,
                    ]);
    
                    DB::table('bidder')->where('nft_id',$nft->id)->where('nft_token',$nft->nft_token)->delete();

                    DB::table('notifications')->insert([
                        'user_id' => $nft->user_id,
                        'label' => 6,
                        'message' => "NFT you have Registered for Auction is Deactivated Because No one bade on it",
                    ]);

                }
                else
                {
                    DB::table('nft')->where('id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->where('activation',1)->update([
                        'status' => 0,
                        'activation' => 0,
                        'highest_coin' => 0,
                        'highest_coin' => 0,
                        'expire' => '',
                        'failed' => $failed + 1,
                    ]);
    
                    DB::table('bidder')->where('nft_id',$nft->id)->where('nft_token',$nft->nft_token)->delete();

                    DB::table('nft')->where('id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->where('failed',">",3)->where('activation',1)->delete();

                    DB::table('notifications')->insert([
                        'user_id' => $nft->user_id,
                        'label' => 6,
                        'message' => "NFT you have Registered for Auction is Deactivated Because No one bade on it",
                    ]);

                }
            }

        }


        return view("index",['nfts'=>$data,'total_customer'=>$total]);
    }

    //nft view
    function createView()
    {

        $data = DB::table("nftcat")->where("status",1)->get();

        $total = DB::table("nftcat")->where("status",1)->count();

        return view("create",['categories'=>$data,'total_categories'=>$total]);
    }







    //logical controller

    //view full product
    function viewNFTdetailedView(Request $request)
    {
        $nft_token = $request->nft_token;

        $find_token = DB::table("nft")->where('nft_token',$nft_token)->count();

        if($find_token == 1)
        {
            $get_nft = DB::table('nft')->where('nft_token',$nft_token)->get()->first();

            if($get_nft->status == 1)
            {
                return view('product-details',['nft'=>$get_nft]);
            }
            else
            {
                session()->flash("error","NFT you are looking for is removed by user...!!!");
                return redirect("/home");                
            }

        }
        else
        {
            session()->flash("error","NFT you are looking for is not exist...!!!");
            return redirect("/home");
        }



    }


    //collection View
    function collectionView()
    {

        $count = DB::table('collection')->where('status',1)->where('user_id',session("NFTuserID"))->count();

        $data = array();

        if($count > 0)
        {
            $data = DB::table('collection')->where('user_id',session('NFTuserID'))->get();
        }
        else
        {
            $count = array();
        }

        return view('/collection',['collection'=>$data]);
    }

    //viewNotification

    function viewNotification()
    {
        $count = DB::table('notifications')->where('status',1)->where('user_id',session("NFTuserID"))->count();

        $data = array();

        if($count > 0)
        {
            $data = DB::table('notifications')->where('user_id',session('NFTuserID'))->where('status',1)->orWhere('status',0)->orderBy("created_at","DESC")->get();

        }
        else
        {
            $count = array();
        }

        return view('/notification',['notifications'=>$data]);
    }
    
}
