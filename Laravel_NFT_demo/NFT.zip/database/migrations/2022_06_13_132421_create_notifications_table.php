<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNotificationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('notifications', function (Blueprint $table) {
            $table->id();
            $table->integer("user_id");
            $table->integer("label")->comment("1 == Register || 2 == Login || 3 == Logout || 4 == I put nft on sell || 5 ==  some one bid on it || 6 == failed || 7 == someone win nft || 8 == got money on sold nft || 9 ==  bought new nft || 10 == no balance || 11 == buy prime || 11 changed password || 12 == used referal coe");
            $table->string("message");
            $table->integer('status')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('notifications');
    }
}
