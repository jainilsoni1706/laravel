<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user', function (Blueprint $table) {
            $table->id();
            $table->string("username")->unique();
            $table->string("firstname");
            $table->string("lastname");
            $table->string("email")->unique();
            $table->string("password");
            $table->date("dob")->nullable();
            $table->bigInteger("phone")->unique();
            $table->string("country")->default("");
            $table->string("state")->default("");
            $table->string("city")->default("");
            $table->string("gender")->default("")->comment("1 == Male & 2 == Female & 3 == Other");
            $table->text("profile")->default("noprofile.png");
            $table->text("cover_profile")->default("nocoverprofile.png");
            $table->integer("sold")->default(0);
            $table->integer("bought")->default(0);
            $table->string("interest")->default("");
            $table->text("token1")->default("")->comment("Login Token");
            $table->text("token2")->default("");
            $table->text("token3")->default("");
            $table->text("authentication_token")->default("");
            $table->text("ip")->default("");
            $table->integer("authentication_type")->default(1)->comment("1 == Normal Login & 2 == Google Login & 3 == Facebook Login & 4 == Twitter Login & 5 == Github Login");
            $table->integer("verified")->default(0);
            $table->integer("coin")->default(0);
            $table->integer("diamond")->default(0);
            $table->integer("status")->default(0);
            $table->string("referal")->default("");
            $table->string("referer")->default(0);
            $table->integer("prime")->default(0)->comment("0 == Non VIP & 1 == VIP (Prime)");
            $table->integer("point")->default(0)->comment(" Under 1k Newbie && 1k = B3 5k = B2 10k = B1 && 30k = S3 60k = S2 100k = S1 && 300k = G3 500k = G2 1000k = G1");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user');
    }
}
