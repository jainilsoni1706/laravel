<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNftTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('nft', function (Blueprint $table) {
            $table->id();
            $table->string("nft_token")->unique();
            $table->integer("user_id");
            $table->date("expire");
            $table->text("image1");
            $table->text("image2");
            $table->text("image3");
            $table->text("title");
            $table->integer("coin");
            $table->integer("highest_coin")->default(0);
            $table->integer("category");
            $table->text("description");
            $table->integer("for_prime")->default(0)->comment("0 AnyOneCanBuy & 1 = Only Vip can buy");
            $table->integer("activation")->default(0);
            $table->integer("status")->default(1);
            $table->integer("failed")->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('nft');
    }
}
