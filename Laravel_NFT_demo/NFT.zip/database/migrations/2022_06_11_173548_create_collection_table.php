<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCollectionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('collection', function (Blueprint $table) {
            $table->id();
            $table->string("nft_token")->unique();
            $table->integer("bought_from");
            $table->integer("user_id");
            $table->text("image1");
            $table->text("image2");
            $table->text("image3");
            $table->text("title");
            $table->integer("price");
            $table->integer("category");
            $table->integer("is_prime")->default(0)->comment("0 AnyOneCanBuy & 1 = Only Vip can buy");
            $table->integer("status")->default(1);
            $table->date("bought_date");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('collection');
    }
}
