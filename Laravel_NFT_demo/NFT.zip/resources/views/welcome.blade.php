<html>
   <head>
      <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
      <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <!-- CSS only -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
      <!-- JavaScript Bundle with Popper -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
   </head>
   <body>
  


    <form action="data.php" method="POST">
        From Date:<br/>
        <input class='fromdate' name="fromdate" /><br/>
        To Date:<br/>
        <input class='todate' name="todate"/><br/><br/>
        Calculated Date:<br/>
        <input class='calculated' name="totalday" /><br/><br/>
        <p>Select Date of Birth: <input type="date" name="age" id="DOB" ></p>
           <div class="row">
              <div class="col-sm-4" style="float:right;">
                 <select name="detail" id="" class="form-control form-select">
                    <option value="Select USA and Canada or Otherwise">Select USA and Canada or Otherwise </option>
                    <option value="Excluding USA and CANADA"> Excluding USA and CANADA</option>
                    <option value="Including USA and CANADA (Worldwide)"> Including USA and CANADA (Worldwide)</option>
                 </select>
              </div>
              <div class="col-sm-4" style="float: right;">
                 <select name="detail2" class="form-control form-select">
                    <option disabled>Choose Package</option>
                    <option value="50k">50K</option>
                    <option value="250k">250K</option>
                    <option value="500k">500K</option>
                    <option value="1000k">1000K</option>
                 </select>
  
              
  
              </div>
           </div><br>
           Insurance Rates:<br/>
           <input type="number" name="insurance" id="">
    </form>

   </body>
</html>


<script>
   var global_age = null;
   $(".table1").hide();
   $(".table2").hide();


   $( function() {
    $( "#datepicker" ).datepicker();
  } );
$('.fromdate').datepicker({
dateFormat: 'yy-mm-dd',
changeMonth: true,
changeYear: true,
});
$('.todate').datepicker({
dateFormat: 'yy-mm-dd',
changeMonth: true,
changeYear: true,
});
$('.fromdate').datepicker().bind("change", function () {
var minValue = $(this).val();
minValue = $.datepicker.parseDate("yy-mm-dd", minValue);
$('.todate').datepicker("option", "minDate", minValue);
calculate();
});
$('.todate').datepicker().bind("change", function () {
var maxValue = $(this).val();
maxValue = $.datepicker.parseDate("yy-mm-dd", maxValue);
$('.fromdate').datepicker("option", "maxDate", maxValue);
calculate();
});
function calculate() {
var d1 = $('.fromdate').datepicker('getDate');
var d2 = $('.todate').datepicker('getDate');
var oneDay = 24*60*60*1000;
var diff = 0;
if (d1 && d2) {

diff = Math.round(Math.abs((d2.getTime() - d1.getTime())/(oneDay) + 1));
}
$('.calculated').val(diff);
}




</script>