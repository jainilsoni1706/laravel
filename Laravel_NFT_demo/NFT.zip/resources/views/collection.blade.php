@include('include.header')
    <!-- start page title area -->
    <div class="rn-breadcrumb-inner ptb--30">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6 col-12">
                    <h5 class="title text-center text-md-start">Our Collection</h5>
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <ul class="breadcrumb-list">
                        <li class="item"><a href="index.html">Home</a></li>
                        <li class="separator"><i class="feather-chevron-right"></i></li>
                        <li class="item current">Collection</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- end page title area -->

    <!-- collection area Start -->
    <div class="rn-collection-area rn-section-gapTop">
        <div class="container">
            <div class="row g-5">




             @forelse ($collection as $item)
                    <!-- start single collention -->
                <div data-sal="slide-up" data-sal-delay="150" data-sal-duration="800" class="col-lg-4 col-xl-3 col-md-6 col-sm-6 col-12">
                    <a href="{{ url("view_collection/$item->nft_token") }}" class="rn-collection-inner-one">
                        <div class="collection-wrapper">
                            <div class="collection-big-thumbnail">
                                <img src="{{ Help::NFTI($item->image1) }}" alt="Nft_Profile">
                            </div>
                            <div class="collenction-small-thumbnail">
                                <img src="{{ Help::NFTI($item->image1) }}" alt="Nft_Profile">
                                <img src="{{ Help::NFTI($item->image2) }}" alt="Nft_Profile">
                                <img src="{{ Help::NFTI($item->image3) }}" alt="Nft_Profile">
                            </div>
                            <div class="collection-deg">
                                <h6 class="title">{{$item->title}}</h6>
                                <span class="items">View</span>
                            </div>
                        </div>
                    </a>
                </div>
                <!-- End single collention -->
             @empty
                 <center>
                    <h1>There No NFT in your Collection</h1>
                 </center>
             @endforelse




            </div>
            <div class="row">
                <div class="col-lg-12" data-sal="slide-up" data-sal-delay="550" data-sal-duration="800">
                    <nav class="pagination-wrapper" aria-label="Page navigation example">
                        <ul class="pagination">
                            <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                            <li class="page-item"><a class="page-link active" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#">Next</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- collection area End -->


    @include('include.footer')
    @include('include.message')
