<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title> Skynet NFT Exchanges | Login </title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="theme-style-mode" content="1"> <!-- 0 == light, 1 == dark -->

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">
    <!-- CSS 
    ============================================ -->
    <link rel="stylesheet" href="{{Help::css('vendor/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{Help::css('vendor/slick.css')}}">
    <link rel="stylesheet" href="{{Help::css('vendor/slick-theme.css')}}">
    <link rel="stylesheet" href="{{Help::css('vendor/nice-select.css')}}">
    <link rel="stylesheet" href="{{Help::css('plugins/feature.css')}}">
    <link rel="stylesheet" href="{{Help::css('plugins/jquery-ui.min.css')}}">
    <link rel="stylesheet" href="{{Help::css('vendor/odometer.css')}}">

    <!-- Style css -->
    <link rel="stylesheet" href="{{Help::css('style.css')}}">

    <style>
        body
        {
            background-color: #181822!important;
            height: 100vh;
        }
    </style>
</head>

<body class="template-color-1 nft-body-connect">

    <!-- login form -->
    <div class="login-area rn-section-gapTop">
        <div class="container">
            <div class="row g-5">
                <div class=" offset-2 col-lg-4 col-md-6 ml_md--0 ml_sm--0 col-sm-12">
                    <div class="form-wrapper-one">
                        <h4>Login</h4>
                        <form action="{{ url('loginuser') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="mb-5">
                                <label for="exampleInputEmail1" class="form-label">Email address</label>
                                <input type="email" id="exampleInputEmail1" name="email">
                            </div>
                            <div class="mb-5">
                                <label for="exampleInputPassword1" class="form-label">Password</label>
                                <input type="password" id="exampleInputPassword1" name="password">
                            </div>
                            <button type="submit" class="btn btn-primary mr--15">Log In</button>
                            <a href="{{ url('signup') }}" class="btn btn-primary-alta">Sign Up</a>
                        </form>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="social-share-media form-wrapper-one">
                        <h6>Another way to log in</h6>
                        <p> Here some different ways to login </p>
                        <button class="another-login login-facebook"> <img class="small-image" src="{{Help::image('icons/google.png')}}" alt=""> <span>Log in with Google</span></button>
                        <button class="another-login login-facebook"> <img class="small-image" src="{{Help::image('icons/facebook.png')}}" alt=""> <span>Log in with Facebook</span></button>
                        <button class="another-login login-twitter"> <img class="small-image" src="{{Help::image('icons/tweeter.png')}}" alt=""> <span>Log in with Twitter</span></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- login form end -->



    <!-- End Top To Bottom Area  -->
    <!-- JS ============================================ -->
    <script src="{{Help::js('vendor/jquery.js')}}"></script>
    <script src="{{Help::js('vendor/jquery.nice-select.min.js')}}"></script>
    <script src="{{Help::js('vendor/jquery-ui.js')}}"></script>
    <script src="{{Help::js('vendor/modernizer.min.js')}}"></script>
    <script src="{{Help::js('vendor/feather.min.js')}}"></script>
    <script src="{{Help::js('vendor/slick.min.js')}}"></script>
    <script src="{{Help::js('vendor/bootstrap.min.js')}}"></script>
    <script src="{{Help::js('vendor/sal.min.js')}}"></script>
    <script src="{{Help::js('vendor/particles.js')}}"></script>
    <script src="{{Help::js('vendor/jquery.style.swicher.js')}}"></script>
    <script src="{{Help::js('vendor/js.cookie.js')}}"></script>
    <script src="{{Help::js('vendor/count-down.js')}}"></script>
    <script src="{{Help::js('vendor/isotop.js')}}"></script>
    <script src="{{Help::js('vendor/imageloaded.js')}}"></script>
    <script src="{{Help::js('vendor/backtoTop.js')}}"></script>
    <script src="{{Help::js('vendor/odometer.js')}}"></script>
    <script src="{{Help::js('vendor/jquery-appear.js')}}"></script>
    <script src="{{Help::js('vendor/scrolltrigger.js')}}"></script>
    <script src="{{Help::js('vendor/jquery.custom-file-input.js')}}"></script>
    <script src="{{Help::js('vendor/savePopup.js')}}"></script>
    <script src="{{Help::js('vendor/vanilla.tilt.js')}}"></script>
    
    <!-- main JS -->
    <script src="{{Help::js('main.js')}}"></script>
    <!-- Meta Mask  -->
    <script src="{{Help::js('vendor/web3.min.js')}}"></script>
    <script src="{{Help::js('vendor/maralis.js')}}"></script>
    <script src="{{Help::js('vendor/nft.js')}}"></script>
</body>


<!-- Mirrored from rainbowit.net/html/nuron/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Jun 2022 10:14:43 GMT -->
</html>
@include("include.message")