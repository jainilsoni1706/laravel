@include("include.header")


    <!-- start banner area 111 -->
    <div class="banner banner-15 ptb--120 bg-color--3 my-random-banner-1">
        <div class="container">
            <div class="row g-5 d-flex align-items-center">
                <div class="col-xxl-7 xl-xl-6 col-lg-6 col-md-12">
                    <h1 class="mb-5 title">Buy and sell <br>
                        digital art, <br>
                        <span>NFT's Collection</span>
                    </h1>
                    <p class="disc">A non-fungible token (NFT) is a non-interchangeable unit of data stored on a
                        blockchain, a form of digital ledger, that can be sold and traded.</p>
                    <div class="btn-group">
                        <a class="btn btn-primary rounded btn-large mr--30 mr_sm--10" href="#">Explore</a>
                        <a class="btn btn-primary-alta rounded btn-large" href="create.html">Create Nft</a>
                    </div>
                </div>
                <div class="col-xxl-5 xl-xl-6 col-lg-6 col-md-12">
                    <div class="expo-15-wrapper tilt" style="will-change: transform; transform: perspective(500px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
                        <div class="thumb-wrapepr">
                            <img class="main jump" src="{{Help::image('banner/banner-04.png')}}" alt="NFt-Product">
                            <img class="main main-2 jump" src="{{Help::image('banner/banner-05.png')}}" alt="NFt-Product">
                        </div>
                        <div class="odometer-area-slide jump">
                            <div class="single-odometer">
                                <h3 class="counter">
                                    <span class="odometer odometer-auto-theme" data-count="3091"><div class="odometer-inside"><span class="odometer-digit"><span class="odometer-digit-spacer">8</span><span class="odometer-digit-inner"><span class="odometer-ribbon"><span class="odometer-ribbon-inner"><span class="odometer-value">3</span></span></span></span></span><span class="odometer-formatting-mark">,</span><span class="odometer-digit"><span class="odometer-digit-spacer">8</span><span class="odometer-digit-inner"><span class="odometer-ribbon"><span class="odometer-ribbon-inner"><span class="odometer-value">0</span></span></span></span></span><span class="odometer-digit"><span class="odometer-digit-spacer">8</span><span class="odometer-digit-inner"><span class="odometer-ribbon"><span class="odometer-ribbon-inner"><span class="odometer-value">9</span></span></span></span></span><span class="odometer-digit"><span class="odometer-digit-spacer">8</span><span class="odometer-digit-inner"><span class="odometer-ribbon"><span class="odometer-ribbon-inner"><span class="odometer-value">1</span></span></span></span></span></div></span>
                                    <span class="counter-label">Collectibles</span>
                                </h3>
                            </div>
                            <div class="single-odometer sal-animate">
                                <h3 class="counter">
                                    <span class="odometer odometer-auto-theme" data-count="1020"><div class="odometer-inside"><span class="odometer-digit"><span class="odometer-digit-spacer">8</span><span class="odometer-digit-inner"><span class="odometer-ribbon"><span class="odometer-ribbon-inner"><span class="odometer-value">1</span></span></span></span></span><span class="odometer-formatting-mark">,</span><span class="odometer-digit"><span class="odometer-digit-spacer">8</span><span class="odometer-digit-inner"><span class="odometer-ribbon"><span class="odometer-ribbon-inner"><span class="odometer-value">0</span></span></span></span></span><span class="odometer-digit"><span class="odometer-digit-spacer">8</span><span class="odometer-digit-inner"><span class="odometer-ribbon"><span class="odometer-ribbon-inner"><span class="odometer-value">2</span></span></span></span></span><span class="odometer-digit"><span class="odometer-digit-spacer">8</span><span class="odometer-digit-inner"><span class="odometer-ribbon"><span class="odometer-ribbon-inner"><span class="odometer-value">0</span></span></span></span></span></div></span>
                                    <span class="counter-label">Auctions</span>
                                </h3>
                            </div>
                            <div class="single-odometer sal-animate">
                                <h3 class="counter">
                                    <span class="odometer odometer-auto-theme" data-count="5329"><div class="odometer-inside"><span class="odometer-digit"><span class="odometer-digit-spacer">8</span><span class="odometer-digit-inner"><span class="odometer-ribbon"><span class="odometer-ribbon-inner"><span class="odometer-value">5</span></span></span></span></span><span class="odometer-formatting-mark">,</span><span class="odometer-digit"><span class="odometer-digit-spacer">8</span><span class="odometer-digit-inner"><span class="odometer-ribbon"><span class="odometer-ribbon-inner"><span class="odometer-value">3</span></span></span></span></span><span class="odometer-digit"><span class="odometer-digit-spacer">8</span><span class="odometer-digit-inner"><span class="odometer-ribbon"><span class="odometer-ribbon-inner"><span class="odometer-value">2</span></span></span></span></span><span class="odometer-digit"><span class="odometer-digit-spacer">8</span><span class="odometer-digit-inner"><span class="odometer-ribbon"><span class="odometer-ribbon-inner"><span class="odometer-value">9</span></span></span></span></span></div></span>
                                    <span class="counter-label">NFT Artist</span>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End banner area -->


    <!-- start banner area 222 -->
    <div class="slider-one rn-section-gapTop my-random-banner-2">
        <div class="container">
            <div class="row row-reverce-sm align-items-center">
                <div class="col-lg-5 col-md-6 col-sm-12 mt_sm--50">
                    <h2 class="title" data-sal-delay="200" data-sal="slide-up" data-sal-duration="800">Discover Digital Art, Collect and Sell Your Specific NFTs.</h2>
                    <p class="slide-disc" data-sal-delay="300" data-sal="slide-up" data-sal-duration="800">Partner with one of the world’s largest retailers to showcase your brand and
                        products.</p>
                    <div class="button-group">
                        <a class="btn btn-large btn-primary" href="#" data-sal-delay="400" data-sal="slide-up" data-sal-duration="800">Get Started</a>
                        <a class="btn btn-large btn-primary-alta" href="{{url('create')}}" data-sal-delay="500" data-sal="slide-up" data-sal-duration="800">Create</a>
                    </div>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12 offset-lg-1">
                    <div class="slider-thumbnail">
                        <img src="{{Help::image('slider/slider-1.png')}}" alt="Slider Images">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End banner area -->


    <!-- start banner area 333 -->
    <div class="slider-area ptb--60 my-random-banner-3">
        <div class="container-fluid padding-contorler-am-slide">
            <div class="row d-flex align-items-center">
                <div class="col-lg-12 col-xl-6 order-2 order-xl-1 padding-contorler-am-slide-right">

                    <div class="banner-top-rating sal-animate">
                        <div class="banner-badge-top sal-animate" data-sal-delay="300" data-sal="slide-up" data-sal-duration="500">
                            <div class="icon">
                                <img src="{{Help::image('icons/rating-2.png')}}" alt="Icons Images">
                            </div>
                            <span class="subtitle">{{$total_customer}}+ Trust Customer</span>
                        </div>

                        <div class="banner-badge-top sal-animate" data-sal-delay="500" data-sal="slide-up" data-sal-duration="500">
                            <div class="icon">
                                <img src="{{Help::image('icons/trophy.png')}}" alt="Icons Images">
                            </div>
                            <span class="subtitle">#1 Top New theme</span>
                        </div>
                    </div>

                    <h1 class="title large-height theme-color sal-animate" data-sal-delay="200" data-sal="slide-up" data-sal-duration="800">Discover Digital Art and<br> Sell  Your Specific NFTs. </h1>
                    <p class="slide-disc sal-animate" data-sal-delay="300" data-sal="slide-up" data-sal-duration="800">a non-interchangeable unit of data stored on a blockchain, a form of digital ledger, that can be sold and traded. Types of NFT data units.</p>
                    <div class="button-group">
                        <a class="btn btn-large btn-primary sal-animate" href="#" data-sal-delay="400" data-sal="slide-up" data-sal-duration="800">Get Started</a>
                        <a class="btn btn-large btn-primary-alta sal-animate" href="create.html" data-sal-delay="500" data-sal="slide-up" data-sal-duration="800">Create</a>
                    </div>
                </div>
                <div class="col-lg-12 col-xl-6 order-1 order-xl-2">

                    <div class="banner-gallery-wrapper">
                        <div class="banner-gallery-loop">
                            <div class="banner-gallery banner-gallery-1 mt--90">
                                <img src="{{Help::image('banner/banner-01.png')}}" alt="Banner Images">
                                <img src="{{Help::image('banner/banner-01.png')}}" alt="Banner Images">
                            </div>
                            <div class="banner-gallery banner-gallery-2">
                                <img src="{{Help::image('banner/banner-02.png')}}" alt="Banner Images">
                                <img src="{{Help::image('banner/banner-02.png')}}" alt="Banner Images">
                            </div>
                            <div class="banner-gallery banner-gallery-3 mt--90">
                                <img src="{{Help::image('banner/banner-03.png')}}" alt="Banner Images">
                                <img src="{{Help::image('banner/banner-03.png')}}" alt="Banner Images">
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End banner area -->

    <!-- Explore Style Carousel -->
    <div class="rn-live-bidding-area rn-section-gapTop">
        <div class="container">
            <div class="row mb--50">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h3 class="title mb--0 live-bidding-title" data-sal-delay="150" data-sal="slide-up" data-sal-duration="800">Live Bidding</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="banner-one-slick slick-activation-03 slick-arrow-style-one rn-slick-dot-style slick-gutter-15">







                        @forelse ($nfts as $nft)
                        <!-- start single product -->
                        <div class="single-slide-product">
                            <div class="product-style-one">
                                <div class="card-thumbnail">
                                    <a href="{{ url("/viewnft/$nft->nft_token") }}"><img src="{{Help::NFTI($nft->image1)}}" alt="NFT_portfolio"></a>
                                    <div class="countdown" data-date="{{$nft->expire}}">
                                        <div class="countdown-container days">
                                            <span class="countdown-value">87</span>
                                            <span class="countdown-heading">D's</span>
                                        </div>
                                        <div class="countdown-container hours">
                                            <span class="countdown-value">23</span>
                                            <span class="countdown-heading">H's</span>
                                        </div>
                                        <div class="countdown-container minutes">
                                            <span class="countdown-value">38</span>
                                            <span class="countdown-heading">Min's</span>
                                        </div>
                                        <div class="countdown-container seconds">
                                            <span class="countdown-value">27</span>
                                            <span class="countdown-heading">Sec</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-share-wrapper">
                                    <div class="profile-share">
                                        <a href="author.html" class="avatar" data-tooltip="Mark JOrdan"><img src="{{ Help::image('client/client-2.png') }}" alt="Nft_Profile"></a>
                                        <a href="author.html" class="avatar" data-tooltip="Mark"><img src="{{ Help::image('client/client-3.png') }}" alt="Nft_Profile"></a>
                                        <a href="author.html" class="avatar" data-tooltip="Jordan"><img src="{{ Help::image('client/client-5.png') }}" alt="Nft_Profile"></a>
                                        <a class="more-author-text" href="#">20+ Place Bit.</a>
                                    </div>
                                    <div class="share-btn share-btn-activation dropdown">
                                        <button class="icon" data-bs-toggle="dropdown" aria-expanded="false">
                                            <svg viewBox="0 0 14 4" fill="none" width="16" height="16" class="sc-bdnxRM sc-hKFxyN hOiKLt">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M3.5 2C3.5 2.82843 2.82843 3.5 2 3.5C1.17157 3.5 0.5 2.82843 0.5 2C0.5 1.17157 1.17157 0.5 2 0.5C2.82843 0.5 3.5 1.17157 3.5 2ZM8.5 2C8.5 2.82843 7.82843 3.5 7 3.5C6.17157 3.5 5.5 2.82843 5.5 2C5.5 1.17157 6.17157 0.5 7 0.5C7.82843 0.5 8.5 1.17157 8.5 2ZM11.999 3.5C12.8274 3.5 13.499 2.82843 13.499 2C13.499 1.17157 12.8274 0.5 11.999 0.5C11.1706 0.5 10.499 1.17157 10.499 2C10.499 2.82843 11.1706 3.5 11.999 3.5Z" fill="currentColor"></path>
                                            </svg>
                                        </button>

                                        <div class="share-btn-setting dropdown-menu dropdown-menu-end">
                                            <button type="button" class="btn-setting-text share-text" data-bs-toggle="modal" data-bs-target="#shareModal">
                                                Share
                                            </button>
                                            <button type="button" class="btn-setting-text report-text" data-bs-toggle="modal" data-bs-target="#reportModal">
                                                Report
                                            </button>
                                        </div>

                                    </div>

                                </div>
                                <a href="{{ url("/viewnft/$nft->nft_token") }}"><span class="product-name"> {{$nft->title}} </span></a>
                                <div class="bid-react-area">
                                    <div class="last-bid">{{$nft->coin}}</div>
                                </div>
                            </div>
                        </div>
                        <!-- end single product -->
                        @empty
                            
                        @endforelse
    







                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Explore Style Carousel End-->

    <!-- start service area -->
    <div class="rn-service-area rn-section-gapTop">
        <div class="container">
            <div class="row">
                <div class="col-12 mb--50">
                    <h3 class="title" data-sal-delay="150" data-sal="slide-up" data-sal-duration="800">Create and sell your NFTs</h3>
                </div>
            </div>
            <div class="row g-5">
                <!-- start single service -->
                <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    <div data-sal="slide-up" data-sal-delay="150" data-sal-duration="800" class="rn-service-one color-shape-7">
                        <div class="inner">
                            <div class="icon">
                                <img src="{{Help::image('icons/shape-7.png')}}" alt="Shape">
                            </div>
                            <div class="subtitle">Step-01</div>
                            <div class="content">
                                <h4 class="title"><a href="#">Set up your wallet</a></h4>
                                <p class="description">Powerful features and inclusions, which makes Nuron standout,
                                    easily customizable and scalable.</p>
                                <a class="read-more-button" href="#"><i class="feather-arrow-right"></i></a>
                            </div>
                        </div>
                        <a class="over-link" href="#"></a>
                    </div>
                </div>
                <!-- End single service -->
                <!-- start single service -->
                <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    <div data-sal="slide-up" data-sal-delay="200" data-sal-duration="800" class="rn-service-one color-shape-1">
                        <div class="inner">
                            <div class="icon">
                                <img src="{{Help::image('icons/shape-1.png')}}" alt="Shape">
                            </div>
                            <div class="subtitle">Step-02</div>
                            <div class="content">
                                <h4 class="title"><a href="#">Create your collection</a></h4>
                                <p class="description">A great collection of beautiful website templates for your need.
                                    Choose the best suitable template.</p>
                                <a class="read-more-button" href="#"><i class="feather-arrow-right"></i></a>
                            </div>
                        </div>
                        <a class="over-link" href="#"></a>
                    </div>
                </div>
                <!-- End single service -->
                <!-- start single service -->
                <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    <div data-sal="slide-up" data-sal-delay="250" data-sal-duration="800" class="rn-service-one color-shape-5">
                        <div class="inner">
                            <div class="icon">
                                <img src="{{Help::image('icons/shape-5.png')}}" alt="Shape">
                            </div>
                            <div class="subtitle">Step-03</div>
                            <div class="content">
                                <h4 class="title"><a href="#">Add your NFT's</a></h4>
                                <p class="description">We've made the template fully responsive, so it looks great on
                                    all devices: desktop, tablets and.</p>
                                <a class="read-more-button" href="#"><i class="feather-arrow-right"></i></a>
                            </div>
                        </div>
                        <a class="over-link" href="#"></a>
                    </div>
                </div>
                <!-- End single service -->
                <!-- start single service -->
                <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    <div data-sal="slide-up" data-sal-delay="300" data-sal-duration="800" class="rn-service-one color-shape-6">
                        <div class="inner">
                            <div class="icon">
                                <img src="{{Help::image('icons/shape-6.png')}}" alt="Shape">
                            </div>
                            <div class="subtitle">Step-04</div>
                            <div class="content">
                                <h4 class="title"><a href="#">Sell Your NFT's</a></h4>
                                <p class="description">I throw myself down among the tall grass by the stream as I
                                    lie close to the earth NFT's.</p>
                                <a class="read-more-button" href="#"><i class="feather-arrow-right"></i></a>
                            </div>
                        </div>
                        <a class="over-link" href="#"></a>
                    </div>
                </div>
                <!-- End single service -->
            </div>
        </div>
    </div>
    <!-- End service area -->
    <!-- New items Start -->


    
    <!-- end product area -->
    <!-- collection area Start -->

    <!-- Modal -->
    <div class="rn-popup-modal share-modal-wrapper modal fade" id="shareModal" tabindex="-1" aria-hidden="true">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i data-feather="x"></i></button>
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content share-wrapper">
                <div class="modal-header share-area">
                    <h5 class="modal-title">Share this NFT</h5>
                </div>
                <div class="modal-body">
                    <ul class="social-share-default">
                        <li><a href="#"><span class="icon"><i data-feather="facebook"></i></span><span class="text">facebook</span></a></li>
                        <li><a href="#"><span class="icon"><i data-feather="twitter"></i></span><span class="text">twitter</span></a></li>
                        <li><a href="#"><span class="icon"><i data-feather="linkedin"></i></span><span class="text">linkedin</span></a></li>
                        <li><a href="#"><span class="icon"><i data-feather="instagram"></i></span><span class="text">instagram</span></a></li>
                        <li><a href="#"><span class="icon"><i data-feather="youtube"></i></span><span class="text">youtube</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="rn-popup-modal report-modal-wrapper modal fade" id="reportModal" tabindex="-1" aria-hidden="true">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i data-feather="x"></i></button>
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content report-content-wrapper">
                <div class="modal-header report-modal-header">
                    <h5 class="modal-title">Why are you reporting?
                    </h5>
                </div>
                <div class="modal-body">
                    <p>Describe why you think this item should be removed from marketplace</p>
                    <div class="report-form-box">
                        <h6 class="title">Message</h6>
                        <textarea name="message" placeholder="Write issues"></textarea>
                        <div class="report-button">
                            <button type="button" class="btn btn-primary mr--10 w-auto">Report</button>
                            <button type="button" class="btn btn-primary-alta w-auto" data-bs-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include("include.message")
@include("include.footer")

<script>
    let randomNumber = Math.floor(Math.random()*3+1);

    $(".my-random-banner-1").hide();
    $(".my-random-banner-2").hide();
    $(".my-random-banner-3").hide();

    if(randomNumber === 1)
    {
        $(".my-random-banner-1").show();
        console.log(`Banner 1 and Random Number ${randomNumber}`);
    }
    else if(randomNumber === 2)
    {
        $(".my-random-banner-2").show();
        console.log(`Banner 2 and Random Number ${randomNumber}`);
    }
    else
    {
        $(".my-random-banner-3").show();
        console.log(`Banner 3 and Random Number ${randomNumber}`);
    }

</script>