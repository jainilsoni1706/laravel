<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title> Skynet NFT Exchanges | Signup </title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="theme-style-mode" content="1"> <!-- 0 == light, 1 == dark -->

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="{{ Help::image('favicon.png') }}">
    <!-- CSS 
    ============================================ -->
    <link rel="stylesheet" href="{{Help::css('vendor/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{Help::css('vendor/slick.css')}}">
    <link rel="stylesheet" href="{{Help::css('vendor/slick-theme.css')}}">
    <link rel="stylesheet" href="{{Help::css('vendor/nice-select.css')}}">
    <link rel="stylesheet" href="{{Help::css('plugins/feature.css')}}">
    <link rel="stylesheet" href="{{Help::css('plugins/jquery-ui.min.css')}}">
    <link rel="stylesheet" href="{{Help::css('vendor/odometer.css')}}">

    <!-- Style css -->
    <link rel="stylesheet" href="{{Help::css('style.css')}}">

    <style>
        .error{
            color:red!important;
        }
    </style>

</head>

<body class="template-color-1 nft-body-connect">
    <!-- Start Header -->
    <!-- End Header Area -->

    <!-- login form -->
    <div class="login-area rn-section-gapTop">
        <div class="container">
            <div class="row g-5">
                <div class="offset-2 col-lg-8 col-md-6 ml_md--0 ml_sm--0 col-sm-12">
                    <div class="form-wrapper-one registration-area">
                        <h4>Sign up</h4>
                        <form action="{{ url('/registeruser') }}" method="POST" enctype="multipart/form-data" id="RegistrationForm">
                            @csrf
                            <div class="mb-5 field_error">
                                <label for="firstName" class="form-label">First name</label>
                                <input type="text" id="firstName" name="firstname">
                            </div>
                            <div class="mb-5 field_error">
                                <label for="sastName" class="form-label">Last name</label>
                                <input type="text" id="sastName" name="lastname">
                            </div>
                            <div class="mb-5 field_error">
                                <label for="Username" class="form-label">Username</label>
                                <input type="text" id="Username" name="username">
                            </div>
                            <div class="mb-5 field_error">
                                <label for="exampleInputEmail1" class="form-label">Email address</label>
                                <input type="email" id="exampleInputEmail1" name="email">
                            </div>
                            <div class="mb-5 field_error">
                                <label for="exampleInputPhone1" class="form-label">Phone Number</label>
                                <input type="text" id="exampleInputPhone1" name="phone">
                            </div>
                            <div class="mb-5 field_error">
                                <label for="newPassword" class="form-label">Create Password</label>
                                <input type="password" id="newPassword" name="password">
                            </div>
                            <div class="mb-5 field_error">
                                <label for="do-referal" class="form-label">Referal Code</label>
                                <input type="text" id="do-referal" name="referal" class="referal-check">
                            </div>
                            <div class="mb-5 field_error rn-check-box">
                                <input type="checkbox" class="rn-check-box-input" id="exampleCheck1" name="terms" value="1" checked>
                                <label class="rn-check-box-label" for="exampleCheck1">Allow to all tearms &
                                    condition</label>
                            </div>
                            <button type="submit" class="btn btn-primary mr--15">Sign Up</button>
                            <a href="{{ url('/') }}" class="btn btn-primary-alta">Log In</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- login form end -->


    <!-- End Top To Bottom Area  -->
    <!-- JS ============================================ -->
    <script src="{{Help::js('vendor/jquery.js')}}"></script>
    <script src="{{Help::js('vendor/jquery.nice-select.min.js')}}"></script>
    <script src="{{Help::js('vendor/jquery-ui.js')}}"></script>
    <script src="{{Help::js('vendor/modernizer.min.js')}}"></script>
    <script src="{{Help::js('vendor/feather.min.js')}}"></script>
    <script src="{{Help::js('vendor/slick.min.js')}}"></script>
    <script src="{{Help::js('vendor/bootstrap.min.js')}}"></script>
    <script src="{{Help::js('vendor/sal.min.js')}}"></script>
    <script src="{{Help::js('vendor/particles.js')}}"></script>
    <script src="{{Help::js('vendor/jquery.style.swicher.js')}}"></script>
    <script src="{{Help::js('vendor/js.cookie.js')}}"></script>
    <script src="{{Help::js('vendor/count-down.js')}}"></script>
    <script src="{{Help::js('vendor/isotop.js')}}"></script>
    <script src="{{Help::js('vendor/imageloaded.js')}}"></script>
    <script src="{{Help::js('vendor/backtoTop.js')}}"></script>
    <script src="{{Help::js('vendor/odometer.js')}}"></script>
    <script src="{{Help::js('vendor/jquery-appear.js')}}"></script>
    <script src="{{Help::js('vendor/scrolltrigger.js')}}"></script>
    <script src="{{Help::js('vendor/jquery.custom-file-input.js')}}"></script>
    <script src="{{Help::js('vendor/savePopup.js')}}"></script>
    <script src="{{Help::js('vendor/vanilla.tilt.js')}}"></script>
    <script src="{{Help::js('validator.js')}}"></script>

    <!-- main JS -->
    <script src="{{Help::js('main.js')}}"></script>
    <!-- Meta Mask  -->
    <script src="{{Help::js('vendor/web3.min.js')}}"></script>
    <script src="{{Help::js('vendor/maralis.js')}}"></script>
    <script src="{{Help::js('vendor/nft.js')}}"></script>
</body>

</html>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>

$(".referal-check").on("keyup",(e)=>{

    $.ajax({
        type: "GET",
        url: "url('checkreferal')",
        data: {
            referal: $(this).val(),
        },
        dataType: 'json',
        success: function(data)
        {
            console.log(data)
        }
    });

    
});


    $("#RegistrationForm").validate({
        rules: {
        email: {
            required: true,
            email: true,
        },
        firstname: {
            required: true,
        },
        lastname: {
            required: true,
        },
        username: {
            required: true,
        },
        phone: {
            required: true,
            digits: true,
        },
        password: {
            required: true,
        },
        terms: {
            required: true,
        },
        },
        messages: {
            email: {
            required: "Please enter your email...!!!",
            email: "Please enter correct email address...!!!",
        },
        firstname: {
            required: "Please enter your firstname...!!!",
        },
        lastname: {
            required: "Please enter your lastname...!!!",
        },
        username: {
            required: "Please create a username...!!!",
        },
        phone: {
            required: "Please enter your phone number...!!!",
        },
        password: {
            required: "Please create a password...!!!",
            minlength:8,
            maxlength:16,
        },
        terms: {
            required: "Please accept terms and condition...!!!",
        },
        },
            errorPlacement: function (error, element) {
            element.closest(".field_error").append(error);
        },
    });

</script>





@include("include.message")