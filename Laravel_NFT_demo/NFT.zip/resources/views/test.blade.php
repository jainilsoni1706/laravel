{{-- 
<style>

    .container-of-labels
    {
        width: 300px;
        height: 30px;
        border: 3px solid black;
        padding: 10px;
    }

    .label-x
    {
        height: 20px;
        border: 3px solid black;
        padding: 10px;
        font: 100%;
        background: #ebebeb;
        color: black;
        width: 100px;
        text-align: center;
    }

</style>

<div class="container-of-labels">
    
    <input class="label-x" name="jainil" value="Jainil" disabled>

</div> --}}


<?php 

// $line = "Jainil is a software developer!";

// if(Help::hasContain("",$line) == true)
// {
//     echo "true";
// }
// else
// {
//     echo "false";
// }
// select user_id,nft_token,sum(coin) from bidder group by user_id
$variable = DB::select("select user_id,nft_token,sum(coin) from bidder group by user_id order by coin desc limit 1");
echo "<pre>";
print_r($variable[0]->user_id);
















  //set value to disabled for those whose out dated


  $today_date = Date("Y-m-d");

$failed = 0;

$get_all_nft = DB::table('nft')->where('status',1)->where('activation',1)->get();

foreach($get_all_nft as $nft)
{
    if(Date("Y-m-d",strtotime($today_date)) > Date("Y-m-d",strtotime($nft->expire)))
    {

        $failed = $nft->failed;

            if($nft->failed == "0" || $nft->failed == 0)
            {
                DB::table('nft')->where('id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->where('activation',1)->update([
                    'status' => 0,
                    'activation' => 0,
                    'highest_coin' => 0,
                    'highest_coin' => 0,
                    'expire' => '',
                    'failed' => 1,
                ]);
            }
            else
            {
                DB::table('nft')->where('id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->where('activation',1)->update([
                    'status' => 0,
                    'activation' => 0,
                    'highest_coin' => 0,
                    'highest_coin' => 0,
                    'expire' => '',
                    'failed' => $failed + 1,
                ]);
            }

    }
}

//set value to disabled for those whose out dated

?>