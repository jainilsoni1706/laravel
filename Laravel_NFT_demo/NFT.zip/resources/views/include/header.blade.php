<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Skynet NFT Exchanges</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="theme-style-mode" content="1"> <!-- 0 == light, 1 == dark -->

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="{{ Help::image('favicon.png') }}">
    <!-- CSS 
    ============================================ -->
    <link rel="stylesheet" href="{{Help::css('vendor/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{Help::css('vendor/slick.css')}}">
    <link rel="stylesheet" href="{{Help::css('vendor/slick-theme.css')}}">
    <link rel="stylesheet" href="{{Help::css('vendor/nice-select.css')}}">
    <link rel="stylesheet" href="{{Help::css('plugins/feature.css')}}">
    <link rel="stylesheet" href="{{Help::css('plugins/jquery-ui.min.css')}}">
    <link rel="stylesheet" href="{{Help::css('vendor/odometer.css')}}">

    <!-- Style css -->
    <link rel="stylesheet" href="{{Help::css('style.css')}}">
</head>

<body class="template-color-1 nft-body-connect">
<?php $data = DB::table("user")->where("id",session('NFTuserID'))->where("email",session("NFTuserEmail"))->where('id',session("NFTuserID"))->get()->first(); ?>
    <!-- Start Header -->
    <header class="rn-header haeder-default header--sticky">
        <div class="container">
            <div class="header-inner">
                <div class="header-left">
                    <div class="logo-thumbnail logo-custom-css">
                        <a class="logo-light" ><img src="{{Help::image('logo/logo-white.png')}}" alt="nft-logo"></a>
                        <a class="logo-dark" ><img src="{{Help::image('logo/logo-dark.png')}}" alt="nft-logo"></a>
                    </div>
                    <div class="mainmenu-wrapper">
                        <nav id="sideNav" class="mainmenu-nav d-none d-xl-block">
                            <!-- Start Mainmanu Nav -->
                            <ul class="mainmenu">
                                {{-- <li class="has-droupdown has-menu-child-item">
                                    <a href="{{ url('/home') }}">Home</a>
                                    <ul class="submenu">
                                        <li><a href="{{url('/home')}}">Home page <i class="feather-home"></i></a></li>
                                    </ul>
                                </li> --}}

                                <?php 
                                // $noti_count = DB::table('notifications')->where('user_id',session("NFTuserID"))->where('status',1)->count();
                                $total_noti = DB::table('notifications')->where('user_id',session('NFTuserID'))->where('status',1)->orWhere('status',0)->count();
                                ?>

                                <li><a href="{{ url('/home') }}">Home</a>
                                <li><a href="{{ url('/profile') }}">Profile</a></li>
                                <li><a href="{{ url('/collection') }}">My Collection</a></li>
                                <li><a href="{{ url('/notification') }}">Notifications ({{$total_noti}}) </a></li>
                            </ul>
                            <!-- End Mainmanu Nav -->
                        </nav>
                    </div>
                </div>
                <div class="header-right">
                    <div class="setting-option d-none d-lg-block">
                        <form class="search-form-wrapper" action="#">
                            <input type="search" placeholder="Search Here" aria-label="Search">
                            <div class="search-icon">
                                <button><i class="feather-search"></i></button>
                            </div>
                        </form>
                    </div>
                    <div class="setting-option rn-icon-list d-block d-lg-none">
                        <div class="icon-box search-mobile-icon">
                            <button><i class="feather-search"></i></button>
                        </div>
                        <form id="header-search-1" action="#" method="GET" class="large-mobile-blog-search">
                            <div class="rn-search-mobile form-group">
                                <button type="submit" class="search-button"><i class="feather-search"></i></button>
                                <input type="text" placeholder="Search ...">
                            </div>
                        </form>
                    </div>

                    <div class="setting-option header-btn rbt-site-header" id="rbt-site-header">
                        <div class="icon-box">
                            <a id="connectbtn" class="btn btn-primary-alta btn-small"> Coins: {{ $data->coin }}</a>
                        </div>
                    </div>

                    <div class="setting-option header-btn rbt-site-header" id="rbt-site-header">
                        <div class="icon-box">
                            <a id="connectbtn" class="btn btn-primary-alta btn-small">Points: {{ $data->point }}</a>
                        </div>
                    </div>

                    <div class="setting-option header-btn rbt-site-header" id="rbt-site-header">
                        <div class="icon-box">
                            <a id="connectbtn" href="{{ url('logout') }}" class="btn btn-primary-alta btn-small" style="width:100px;">Logout</a>
                        </div>
                    </div>

                    <div class="header_admin" id="header_admin">
                        <div class="setting-option rn-icon-list user-account">
                            <div class="icon-box">
                                <a href="author.html"><img src="{{Help::image('icons/boy-avater.png')}}" alt="Images"></a>
                                <div class="rn-dropdown">
                                    <div class="rn-inner-top">
                                        <h4 class="title"><a href="product-details.html">Christopher William</a></h4>
                                        <span><a href="#">Set Display Name</a></span>
                                    </div>
                                    <div class="rn-product-inner">
                                        <ul class="product-list">
                                            <li class="single-product-list">
                                                <div class="thumbnail">
                                                    <a href="product-details.html"><img src="{{Help::image('portfolio/portfolio-07.jpg')}}" alt="Nft Product Images"></a>
                                                </div>
                                                <div class="content">
                                                    <h6 class="title"><a href="product-details.html">Balance</a></h6>
                                                    <span class="price">25 ETH</span>
                                                </div>
                                                <div class="button"></div>
                                            </li>
                                            <li class="single-product-list">
                                                <div class="thumbnail">
                                                    <a href="product-details.html"><img src="{{Help::image('portfolio/portfolio-01.jpg')}}" alt="Nft Product Images"></a>
                                                </div>
                                                <div class="content">
                                                    <h6 class="title"><a href="product-details.html">Balance</a></h6>
                                                    <span class="price">25 ETH</span>
                                                </div>
                                                <div class="button"></div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="add-fund-button mt--20 pb--20">
                                        <a class="btn btn-primary-alta w-100" href="connect.html">Add Your More Funds</a>
                                    </div>
                                    <ul class="list-inner">
                                        <li><a href="author.html">My Profile</a></li>
                                        <li><a href="edit-profile.html">Edit Profile</a></li>
                                        <li><a href="connect.html">Manage funds</a></li>
                                        <li><a href="login.html">Sign Out</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="setting-option mobile-menu-bar d-block d-xl-none">
                        <div class="hamberger">
                            <button class="hamberger-button">
                                <i class="feather-menu"></i>
                            </button>
                        </div>
                    </div>

                    <div id="my_switcher" class="my_switcher setting-option">
                        <ul>
                            <li>
                                <a href="javascript: void(0);" data-theme="light" class="setColor light">
                                    <img class="sun-image" src="{{Help::image('icons/sun-01.svg')}}" alt="Sun images">
                                </a>
                            </li>
                            <li>
                                <a href="javascript: void(0);" data-theme="dark" class="setColor dark">
                                    <img class="Victor Image" src="{{Help::image('icons/vector.svg')}}" alt="Vector Images">
                                </a>
                            </li>
                        </ul>
                    </div>


                </div>
            </div>
        </div>
    </header>
    <!-- End Header Area -->

    <div class="popup-mobile-menu">
        <div class="inner">
            <div class="header-top">
                <div class="logo logo-custom-css">
                    <a class="logo-light" href="{{ url('/home') }}"><img src="assets/images/logo/logo-white.png" alt="nft-logo"></a>
                    <a class="logo-dark" href="{{ url('/home') }}"><img src="assets/images/logo/logo-dark.png" alt="nft-logo"></a>
                </div>
                <div class="close-menu">
                    <button class="close-button">
                        <i class="feather-x"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>