
<div style="padding-top: 50px!important;"></div>

    <!-- Start Footer Area -->
    <div class="copy-right-one ptb--20 bg-color--1">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <div class="copyright-left">
                        <span>©2022 Nuron, Inc. All rights reserved.</span>
                        <ul class="privacy">
                            <li><a href="terms-condition.html">Terms</a></li>
                            <li><a href="privacy-policy.html">Privacy Policy</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <div class="copyright-right">
                        <ul class="social-copyright">
                            <li><a href="#"><i data-feather="facebook"></i></a></li>
                            <li><a href="#"><i data-feather="twitter"></i></a></li>
                            <li><a href="#"><i data-feather="instagram"></i></a></li>
                            <li><a href="#"><i data-feather="linkedin"></i></a></li>
                            <li><a href="#"><i data-feather="mail"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Footer Area -->
    <div class="mouse-cursor cursor-outer"></div>
    <div class="mouse-cursor cursor-inner"></div>
    <!-- Start Top To Bottom Area  -->
    <div class="rn-progress-parent">
        <svg class="rn-back-circle svg-inner" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    <!-- End Top To Bottom Area  -->
    <!-- JS ============================================ -->
    <script src="{{Help::js('vendor/jquery.js')}}"></script>
    <script src="{{Help::js('vendor/jquery.nice-select.min.js')}}"></script>
    <script src="{{Help::js('vendor/jquery-ui.js')}}"></script>
    <script src="{{Help::js('vendor/modernizer.min.js')}}"></script>
    <script src="{{Help::js('vendor/feather.min.js')}}"></script>
    <script src="{{Help::js('vendor/slick.min.js')}}"></script>
    <script src="{{Help::js('vendor/bootstrap.min.js')}}"></script>
    <script src="{{Help::js('vendor/sal.min.js')}}"></script>
    <script src="{{Help::js('vendor/particles.js')}}"></script>
    <script src="{{Help::js('vendor/jquery.style.swicher.js')}}"></script>
    <script src="{{Help::js('vendor/js.cookie.js')}}"></script>
    <script src="{{Help::js('vendor/count-down.js')}}"></script>
    <script src="{{Help::js('vendor/isotop.js')}}"></script>
    <script src="{{Help::js('vendor/imageloaded.js')}}"></script>
    <script src="{{Help::js('vendor/backtoTop.js')}}"></script>
    <script src="{{Help::js('vendor/odometer.js')}}"></script>
    <script src="{{Help::js('vendor/jquery-appear.js')}}"></script>
    <script src="{{Help::js('vendor/scrolltrigger.js')}}"></script>
    <script src="{{Help::js('vendor/jquery.custom-file-input.js')}}"></script>
    <script src="{{Help::js('vendor/savePopup.js')}}"></script>
    <script src="{{Help::js('vendor/vanilla.tilt.js')}}"></script>
    <script src="{{Help::js('validator.js')}}"></script>

    <!-- main JS -->
    <script src="{{Help::js('main.js')}}"></script>
    <!-- Meta Mask  -->
    <script src="{{Help::js('vendor/web3.min.js')}}"></script>
    <script src="{{Help::js('vendor/maralis.js')}}"></script>
    <script src="{{Help::js('vendor/nft.js')}}"></script>
</body>


<!-- Mirrored from rainbowit.net/html/nuron/edit-profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Jun 2022 10:14:48 GMT -->
</html>