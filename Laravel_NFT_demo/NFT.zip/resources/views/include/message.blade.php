<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css"/>
@if (session('success'))
<script type="text/javascript">toastr.success('<?php echo session('success'); ?>');</script>
@endif
@if (session('error'))
<script type="text/javascript">toastr.error('<?php echo session('error'); ?>');</script>
@endif

<style>
    .toast-message
    {
        font-size: 15px!important;
    }
</style>