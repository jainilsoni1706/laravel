@include("include.header")


<?php 

function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

?>


    <!-- start page title area -->
    <div class="rn-breadcrumb-inner ptb--30">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6 col-12">
                    <h5 class="title text-center text-md-start">Product Details</h5>
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <ul class="breadcrumb-list">
                        <li class="item"><a href="index.html">Home</a></li>
                        <li class="separator"><i class="feather-chevron-right"></i></li>
                        <li class="item current">Product Details</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- end page title area -->

    <!-- start product details area -->
    <div class="product-details-area rn-section-gapTop">
        <div class="container">
            <div class="row g-5">
                <!-- product image area -->

                <div class="col-lg-7 col-md-12 col-sm-12">
                    <div class="product-tab-wrapper rbt-sticky-top-adjust">
                        <div class="pd-tab-inner">
                            <div class="nav rn-pd-nav rn-pd-rt-content nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                <button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">
                                    <span class="rn-pd-sm-thumbnail">
                                        <img src="{{Help::NFTI($nft->image1)}}" alt="Nft_Profile">
                                    </span>
                                </button>
                                <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">
                                    <span class="rn-pd-sm-thumbnail">
                                        <img src="{{Help::NFTI($nft->image2)}}" alt="Nft_Profile">
                                    </span>
                                </button>
                                <button class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-messages" type="button" role="tab" aria-controls="v-pills-messages" aria-selected="false">
                                    <span class="rn-pd-sm-thumbnail">
                                        <img src="{{Help::NFTI($nft->image3)}}" alt="Nft_Profile">
                                    </span>
                                </button>
                            </div>

                            <div class="tab-content rn-pd-content" id="v-pills-tabContent">
                                <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                                    <div class="rn-pd-thumbnail">
                                        <img src="{{Help::NFTI($nft->image1)}}" alt="Nft_Profile">
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                                    <div class="rn-pd-thumbnail">
                                        <img src="{{Help::NFTI($nft->image2)}}" alt="Nft_Profile">
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                                    <div class="rn-pd-thumbnail">
                                        <img src="{{Help::NFTI($nft->image3)}}" alt="Nft_Profile">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- product image area end -->

                <div class="col-lg-5 col-md-12 col-sm-12 mt_md--50 mt_sm--60">
                    <div class="rn-pd-content-area">
                        <div class="pd-title-area">
                            <h4 class="title"> {{$nft->title}} </h4>
                            <div class="pd-react-area">
                                <div class="count">
                                    <div class="share-btn share-btn-activation dropdown">
                                        <button class="icon" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            <svg viewBox="0 0 14 4" fill="none" width="16" height="16" class="sc-bdnxRM sc-hKFxyN hOiKLt">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M3.5 2C3.5 2.82843 2.82843 3.5 2 3.5C1.17157 3.5 0.5 2.82843 0.5 2C0.5 1.17157 1.17157 0.5 2 0.5C2.82843 0.5 3.5 1.17157 3.5 2ZM8.5 2C8.5 2.82843 7.82843 3.5 7 3.5C6.17157 3.5 5.5 2.82843 5.5 2C5.5 1.17157 6.17157 0.5 7 0.5C7.82843 0.5 8.5 1.17157 8.5 2ZM11.999 3.5C12.8274 3.5 13.499 2.82843 13.499 2C13.499 1.17157 12.8274 0.5 11.999 0.5C11.1706 0.5 10.499 1.17157 10.499 2C10.499 2.82843 11.1706 3.5 11.999 3.5Z" fill="currentColor"></path>
                                            </svg>
                                        </button>

                                        <div class="share-btn-setting dropdown-menu dropdown-menu-end">
                                            <button type="button" class="btn-setting-text share-text" data-bs-toggle="modal" data-bs-target="#shareModal">
                                                Share
                                            </button>
                                            <button type="button" class="btn-setting-text report-text" data-bs-toggle="modal" data-bs-target="#reportModal">
                                                Report
                                            </button>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <span class="bid">Highest bid <span class="price"> {{$nft->highest_coin}} </span></span>
                        <div class="catagory-collection">
                            <div class="catagory">
                                <span> {{$nft->coin}}  <span class="color-body">
                                    {{-- + ( 10 % Tax {{$nft->coin / 10}} ) = {{  $nft->coin + $nft->coin / 10 }} --}}
                                        </span></span>
                            </div>
                        </div>
                        <div class="rn-bid-details">
                            <div class="tab-wrapper-one">
                                <nav class="tab-button-one">
                                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                        <button class="nav-link active" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="true">Details</button>
                                        <button class="nav-link" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="false">Bids</button>
                                    </div>
                                </nav>
                                <div class="tab-content rn-bid-content" id="nav-tabContent">
                                    <div class="tab-pane fade" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                        <!-- single creator -->



                                        @forelse (DB::table('bidder')->where('nft_id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->get() as $x)
                                        <div class="top-seller-inner-one">
                                            <div class="top-seller-wrapper">
                                                <div class="thumbnail">
                                                    <a href="#"><img src="{{Help::profile(DB::table('user')->where('id',$x->user_id)->get()->first()->profile)}}" alt="Nft_Profile"></a>
                                                </div>
                                                <div class="top-seller-content">
                                                    <span> {{$x->coin}} <a href="#"><?php echo DB::table('user')->where('id',$x->user_id)->get()->first()->username ?></a></span>
                                                    <span class="count-number">
                                                        {{time_elapsed_string($x->created_at)}}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        @empty
                                        <div class="top-seller-inner-one">
                                            No one has Bidded Yet.
                                        </div>
                                        @endforelse


                                        <!-- single creator -->
                                        <!-- single creator -->
                                    </div>
                                    <div class="tab-pane fade show active" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                                        <!-- single -->
                                        <div class="rn-pd-bd-wrapper">
                                            <!-- single -->
                                            <div class="rn-pd-sm-property-wrapper">
                                                <h6 class="pd-property-title">
                                                    Description
                                                </h6>
                                                <div class="property-wrapper">
                                                    <!-- single property -->
                                                    <div class="pd-property-inner">
                                                        <span class="color-body type">{{$nft->description}}</span>
                                                    </div>
                                                    <!-- single property End -->
                                                </div>
                                            </div>
                                            <!-- single -->
                                            <!-- single -->
                                            <div class="rn-pd-sm-property-wrapper">
                                                <h6 class="pd-property-title">
                                                    Catagory
                                                </h6>
                                                <div class="catagory-wrapper">
                                                    <!-- single property -->
                                                   @if(Help::containLetter(",",$nft->category) == true)
                                                   @forelse (explode(",",$nft->category) as $cat)
                                                   <div class="pd-property-inner">
                                                       <span class="color-white value">{{DB::table('nftcat')->where('id',$cat)->get()->first()->label}}</span>
                                                   </div>
                                                   @empty
                                                   @endforelse
                                                   @else
                                                   <div class="pd-property-inner">
                                                       <span class="color-white value">{{DB::table('nftcat')->where('id',$nft->category)->get()->first()->label}}</span>
                                                    </div>
                                                   @endif
                                                    <!-- single property End -->
                                                </div>
                                            </div>
                                            <!-- single -->
                                        </div>
                                        <!-- single -->
                                    </div>
                                </div>
                            </div>
                            <div class="place-bet-area">
                                <div class="rn-bet-create">
                                </div>
                                <?php
                                $get_from_bidder_count = DB::table('bidder')->where('nft_id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->where('user_id',session("NFTuserID"))->count();
                                $get_from_nft = DB::table('nft')->where('id',$nft->id)->where('status',1)->where('activation',1)->get()->first();

                                if($get_from_bidder_count > 0)
                                {
                                    $get_from_bidder = DB::table('bidder')->where('nft_id',$nft->id)->where('nft_token',$nft->nft_token)->where('status',1)->where('user_id',session("NFTuserID"))->sum('coin');

                                    if($get_from_bidder == $get_from_nft->highest_coin)
                                    {
                                        ?>
                                    <button class="btn btn-primary-alta mt--30" >You are on Top</button>
                                        <?php
                                    }
                                    else
                                    {
                                        ?>
                                    <button type="button" class="btn btn-primary-alta mt--30" data-bs-toggle="modal" data-bs-target="#placebidModal">Place a Bid</button>
                                        <?php
                                    }
                                }
                                else
                                {
                                    ?>
                                    <button type="button" class="btn btn-primary-alta mt--30" data-bs-toggle="modal" data-bs-target="#placebidModal">Place a Bid</button>
                                    <?php
                                }

                                ?>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End product details area -->





    <!-- Modal -->
    <div class="rn-popup-modal share-modal-wrapper modal fade" id="shareModal" tabindex="-1" aria-hidden="true">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i data-feather="x"></i></button>
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content share-wrapper">
                <div class="modal-header share-area">
                    <h5 class="modal-title">Share this NFT</h5>
                </div>
                <div class="modal-body">
                    <ul class="social-share-default">
                        <li><a href="#"><span class="icon"><i data-feather="facebook"></i></span><span class="text">facebook</span></a></li>
                        <li><a href="#"><span class="icon"><i data-feather="twitter"></i></span><span class="text">twitter</span></a></li>
                        <li><a href="#"><span class="icon"><i data-feather="linkedin"></i></span><span class="text">linkedin</span></a></li>
                        <li><a href="#"><span class="icon"><i data-feather="instagram"></i></span><span class="text">instagram</span></a></li>
                        <li><a href="#"><span class="icon"><i data-feather="youtube"></i></span><span class="text">youtube</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="rn-popup-modal report-modal-wrapper modal fade" id="reportModal" tabindex="-1" aria-hidden="true">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i data-feather="x"></i></button>
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content report-content-wrapper">
                <div class="modal-header report-modal-header">
                    <h5 class="modal-title">Why are you reporting?
                    </h5>
                </div>
                <div class="modal-body">
                    <p>Describe why you think this item should be removed from marketplace</p>
                    <div class="report-form-box">
                        <h6 class="title">Message</h6>
                        <textarea name="message" placeholder="Write issues"></textarea>
                        <div class="report-button">
                            <button type="button" class="btn btn-primary mr--10 w-auto">Report</button>
                            <button type="button" class="btn btn-primary-alta w-auto" data-bs-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <form action="{{ url('/bidonnft') }}" method="POST">
    <div class="rn-popup-modal placebid-modal-wrapper modal fade" id="placebidModal" tabindex="-1" aria-hidden="true">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i data-feather="x"></i></button>
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Place a bid</h3>
                </div>
                <div class="modal-body">
                    <p>You are about to purchase This Product Form Nuron</p>
                    <div class="placebid-form-box">
                        <h5 class="title">Your bid</h5>
                        <div class="bid-content">
                            <div class="bid-content-mid">
                                <div class="bid-content-left">
                                    <span>Your Balance</span>
                                    <span>Bid range</span>
                                    <span>Total bid amount</span>
                                </div>
                                <div class="bid-content-right">
                                    <span> {{Help::balance()}} </span>
                                    <span>
                                        <?php 
                                        $current_price = null;
                                        if($nft->highest_coin != "" || $nft->highest_coin != null || $nft->highest_coin != 0 || $nft->highest_coin != "0")
                                        {
                                            echo 100;
                                        }
                                        else
                                        {
                                            echo 0;
                                        }
                                        ?>
                                    </span>
                                    <span>
                                        <?php 
                                        
                                        if($nft->highest_coin != "" || $nft->highest_coin != null || $nft->highest_coin != 0 || $nft->highest_coin != "0")
                                        {
                                            $current_price = $nft->highest_coin;
                                            echo $nft->highest_coin + 100;
                                        }
                                        else
                                        {
                                            $current_price = $nft->coin;
                                            echo $nft->coin;
                                        }
                                        ?>

                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="bit-continue-button">
                            @csrf
                            <input type="hidden" name="user_id" value="{{session("NFTuserID")}}">
                            <input type="hidden" name="nft_id" value="{{$nft->id}}">
                            <input type="hidden" name="nft_token" value="{{$nft->nft_token}}">
                            <input type="hidden" name="coin" value="{{Help::balance()}}">
                            <input type="hidden" name="current_price" value="{{$current_price}}" >
                            <button type="submit" class="btn btn-primary w-100" data-bs-dismiss="modal">Place a Bid</button>
                            <button type="button" class="btn btn-primary-alta mt--10" data-bs-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </form>
    @include("include.footer")
    @include("include.message")