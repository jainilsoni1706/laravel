@include('include.header')
    <div class="rn-activity-area rn-section-gapTop">
        <div class="container">
            <div class="row mb--30">
                <h3 class="title">All following Acivity</h3>
            </div>
            <div class="row g-6 activity-direction">
                <div class="col-lg-8 mb_dec--15">


                    @forelse ($notifications as $x)
                                            <!-- single activity -->
                    <div class="single-activity-wrapper">
                        <div class="inner">
                            <div class="read-content">
                                <div class="content">
                                    <a href="product-details.html">
                                        <h6 class="title">{{$x->message}}</h6>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- single activity -->
                    @empty
                        <h1>No Notification Available for you...</h1>
                    @endforelse

                </div>
                <div class="col-lg-4">
                    <div class="filter-wrapper">
                        <div class="widge-wrapper rbt-sticky-top-adjust">
                            <div class="inner">
                                <h3>Market filter</h3>
                                <div class="sing-filter">
                                    <button>Login Activity</button>
                                    <button>NFT Bidders</button>
                                    <button>NFT Winner</button>
                                    <button>NFT Fail</button>
                                    <button>Referal Code User</button>
                                    <button>Account Privacy</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('include.footer')
    @include('include.message')