<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Authentication;
use App\Http\Controllers\Transaction;
use App\Http\Controllers\General;




//login view route
Route::get('/',[General::class,'loginView']);
//sign up view route
Route::get('/signup',[General::class,'signupView']);


//login check route
Route::post('/loginuser',[Authentication::class,'login']);

//login check route
Route::post('/registeruser',[Authentication::class,'register']);

//home view route
Route::get('/home',[General::class,'homeView']);

//profile view route
Route::get('/profile',[General::class,'profileView']);

//logout

Route::get('/logout',[Authentication::class,'logout']);

//check referal AJAX

Route::get('/checkreferal',[Authentication::class,'checkReferalCode']);

//create nft view

Route::get('/create',[General::class,'createView']);


//create a nft
Route::post('/createnft',[Transaction::class,'createNFT']);


//view full prodct

Route::get('/viewnft/{nft_token}',[General::class,'viewNFTdetailedView']);


//view full noti

Route::get('/notification',[General::class,'viewNotification']);



//bid on nft

Route::post('/bidonnft',[Transaction::class,'BidOnNft']);


//collection
Route::get('/collection',[General::class,'collectionView']);



























// exceptions

Route::view('welcome','welcome');
Route::view('test','test');